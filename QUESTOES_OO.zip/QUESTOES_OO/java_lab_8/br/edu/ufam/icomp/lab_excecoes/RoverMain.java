package br.edu.ufam.icomp.lab_excecoes;

public class RoverMain {
    public static void main(String[] args) {
        Caminho aux= new Caminho(2);
        
        try{
            Coordenada aux1 = new Coordenada(7, 3, 0);
            aux.addCoordenada(aux1);
        }
        catch(Exception e){
            
        }
        
        
    }
}
