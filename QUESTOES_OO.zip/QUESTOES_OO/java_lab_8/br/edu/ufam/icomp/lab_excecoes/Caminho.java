package br.edu.ufam.icomp.lab_excecoes;

public class Caminho {
 
    
    private Coordenada caminho[]; 
    private	int tamanho;
    private	int maxtamanho;

    public Caminho(int maxTam){
        caminho = new Coordenada[maxTam];
        this.maxtamanho=maxTam;
        this.tamanho=0;
        
        
        
    }
    public	int tamanho(){
        return this.tamanho;
    }

    public void	addCoordenada(Coordenada coordenada) throws TamanhoMaximoExcedidoException, DistanciaEntrePontosExcedidaException{
        
        if (tamanho >= caminho.length) {
            throw new TamanhoMaximoExcedidoException();
        }

        if (tamanho > 0 && caminho[tamanho - 1].distancia(coordenada) > 15) {
            throw new DistanciaEntrePontosExcedidaException();
        }

        caminho[tamanho] = coordenada;
        tamanho++;
    }

        
        
    
    public void	reset(){
        

        this.caminho=null;
        this.tamanho=0;
        
    }
    public String toString(){
        String aux= String.format("Dados do caminho:\n  - Quantidade de pontos: %d\n  - Pontos:\n", this.tamanho);
        for(int i=0;i<this.tamanho;i++){
            aux += "-> " + caminho[i].toString();

        }

        return aux;

    }
}
