package br.edu.ufam.icomp.lab_excecoes;

public class CoordenadaNegativaException extends RoverCoordenadaException{
    public CoordenadaNegativaException(){}
    public CoordenadaNegativaException(String aux){

    }

    public String getMessage(){
        return "Coordenada com valor negativo";
    }    
}
