import java.util.Scanner;
import java.math.*;

public class VolumeCombustivel {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        double vetor[] = new double[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Double.parseDouble(arrayValores[i]);
            
        }
        double  altura_total=vetor[0];//H
        double altura_ar = vetor[1];//h
        double raio= vetor[2];//r
        double alturaC=altura_total-raio*2;//altura do cilindro
        //double volume_Combustivel;
        //System.out.println(vetor[0]+"\n");
        //System.out.println(vetor[1]+"\n");
        //System.out.println(vetor[2]+"\n");
        

        double volume_esfera=(4.0/3.0)*Math.PI*(raio*raio*raio);
        //System.out.println("Accc: "+ (3*raio-altura_ar));
        
        double volume_calota=(Math.PI/3.0)*(altura_ar*altura_ar)*(3*raio-altura_ar);

        double volume_cilindro=Math.PI*(raio*raio)*altura_total;

        double volume_max=volume_esfera+volume_cilindro;

        double resultado=0;
        //volume_Combustivel=volume_esfera-volume_vazio;
   

        if((altura_ar<=0 && altura_total<=0 && raio<=0) || (altura_ar>altura_total)){
            resultado=-1;
        }
        else{
            if(altura_ar<=raio){

                altura_ar=2*raio-altura_ar;
                volume_calota=(Math.PI/3.0)*(altura_ar*altura_ar)*(3*raio-altura_ar);
                //System.out.printf("volume da esfera: %.5f\n",volume_esfera);
                //System.out.printf("volume da calota: %.5f\n",volume_calota);
                resultado=(volume_esfera)-volume_calota;
                
            }
            else if(altura_ar<=raio+alturaC){
                volume_cilindro=Math.PI*(raio*raio)*(altura_ar-raio);
                resultado=(volume_esfera/2)+volume_cilindro;
            }
            else if(altura_ar>raio+alturaC){
                altura_ar=altura_ar-alturaC;
                volume_calota=(Math.PI/3.0)*(altura_ar*altura_ar)*(3*raio-altura_ar);
                volume_esfera=volume_esfera-volume_calota;
                volume_cilindro=Math.PI*(raio*raio)*(altura_total-raio*2);
                resultado=volume_esfera+volume_cilindro;
            }
        }



        
        
        
        
        
        
       /*  System.out.printf("\nVolume da esfera :%.3f", volume_esfera);
        System.out.printf("\nVolume da cilindro :%.3f", volume_cilindro);

        System.out.printf("\nvolume da calota : %.3f\n", volume_calota);

       System.out.printf("\nvolume maximo: %.3f\n",volume_max);
        System.out.printf("\nresultado: %.3f\n",resultado);
        */
        System.out.printf("%.3f",resultado);
        

        }
        
                
    }

