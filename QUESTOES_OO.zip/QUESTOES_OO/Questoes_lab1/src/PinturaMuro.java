//package QUESTOES;
import java.util.Scanner;
public class PinturaMuro {
    public static void main(String[] args) {
        double valorPintor;
        Scanner teclado = new Scanner((System.in));
        valorPintor=teclado.nextDouble();
        teclado.close();
        valorPintor=100+valorPintor*36;
        System.out.printf("%.1f",valorPintor);
    }
}
