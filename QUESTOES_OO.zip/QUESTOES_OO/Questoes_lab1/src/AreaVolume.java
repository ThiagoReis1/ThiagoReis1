//package QUESTOES;
import java.util.Scanner;
import java.math.*;
public class AreaVolume {

    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        double raio= teclado.nextDouble();
        teclado.close();
        double pi=Math.PI;
        double area_Circulo=pi*(raio*raio);
        double volume_esfera=(4.0/3)*pi*(raio*raio*raio);
        
        System.out.printf("Um circulo com raio de %.2f centimetros tem uma area de %.2f centimetros quadrados.",raio,area_Circulo);
        System.out.printf("\nUma esfera com raio de %.2f centimetros tem um volume de %.2f centimetros cubicos.",raio,volume_esfera);        
    }
    
}
