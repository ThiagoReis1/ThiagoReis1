//package QUESTOES;
import java.util.Scanner;
public class AnimaisCedulas {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int valor= teclado.nextInt();
        teclado.close();
        String bicho;
        switch (valor) {
            case 2:
                bicho="Tartaruga";    
                break;
            case 5:
                bicho="Garça";
                break;  
            case 10:
                bicho="Arara";
                break;
            case 20:
                bicho="Mico-leão-dourado";
                break;
            case 50:
                bicho="Onça-pintada";
                break;  
            case 100:
                bicho="Garoupa"; 
                break;        
            default:
                bicho="erro";
                break;
        }
        System.out.println(bicho);
    }

}
