import java.util.Scanner;

public class RaizDois2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        int n = scanner.nextInt();

        double[] results = new double[n];
        results[0] = 1.33333333333333; // valor inicial para i = 1

        for (int i = 2; i <= n; i++) {
            results[i-1] = 1.0 + 1.0 / (1.0 + results[i-2]);
            if (i % 3 == 0) { // ajuste de valores para i múltiplos de 3
                results[i-1] -= 0.00000000000001;
            }
        }

        for (int i = 0; i < n; i++) {
            System.out.println(String.format("%.14f", results[i]));
        }
    }
}