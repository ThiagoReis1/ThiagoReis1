import java.util.Scanner;

public class AprovacaoDisciplina {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        String input = scanner.nextLine();
        String[] tokens = input.split(" ");
        float[] valores = new float[tokens.length];


        //System.out.println("Aqui");

            
        float aprovados = 0;
        float reprovados_nota = 0;
        float reprovados_falta = 0;

        int tamanho_vetor=0;

        

        for (int i = 0,control=0; i < tokens.length; i++) {
            String token = tokens[i];
            valores[i] = Float.parseFloat(token);
            if (valores[i]==-1 && control==0){
                tamanho_vetor=i;
                control=1;
            }
            //System.out.printf("%.2f -> ", valores[i]);
        }

       // System.out.printf("\n\n\n\n Tamanho do vetor: %d\n\n\n\n", tamanho_vetor);
        //System.out.printf("\n\n\n\n Tamanho do vetor String: %d\n\n\n\n", tokens.length);
        float[] vet1 = new float[tamanho_vetor];
        float[] vet2 = new float[tamanho_vetor];

        int vet1C=0;
        float horas=0;
        

        for(int i=0,j=0;i<valores.length;i++){
            if(valores[i]!=-1 && vet1C==0){
                vet1[i]=valores[i];
                //System.out.printf("%.2f -> ", vet1[i]);
            }
            else if(j==tamanho_vetor){
                horas=valores[i];
            }
            else if(valores[i]!=-1 && vet1C==1){
                vet2[j]=valores[i];
                //System.out.printf("%.2f -> ", vet2[j]);
                j++;
            }

            else if(valores[i]==-1){
                vet1C=1;
            }
        }

        /* 
        for(int i=0;i<tamanho_vetor;i++){
            System.out.printf("%d ->", vet1[i]);
        }
        System.out.println();
        for(int i=0;i<tamanho_vetor;i++){
            System.out.printf("%d ->", vet2[i]);
        }
          */

        for(int i=0;i<tamanho_vetor;i++){
            if(vet2[i]<horas*0.75){
                reprovados_falta++;
            }
            else if(vet1[i]>=5.0){
                aprovados++;
            }
            else{
                reprovados_nota++;
            }
        } 

        System.out.printf("%.0f %.0f %.0f",aprovados,reprovados_nota,reprovados_falta);

    }
}
                