//package Questoes_lab1.src;
import java.util.Scanner;
public class AproximacaoSeno {
    public static void main(String[] args) {

    Scanner teclado = new Scanner(System.in);
    String valores=teclado.nextLine();
    String[] arrayValores = valores.split(" ");
    int tam=arrayValores.length;
    float vetor[] = new float[tam];
    teclado.close();
    for(int i=0;i<tam;i++){
        vetor[i]=Integer.parseInt(arrayValores[i]);
        //System.out.println(vetor[i]);
        
    }
    
 
    double angulo= Math.toRadians(vetor[0]);
    double repeticoes=vetor[1];
    double seno=0;
    int num_fat=3;
    

     
    
    //System.out.printf("Angulo: %.10f\n", angulo);//angulo
    //System.out.printf("Repetições: %.10f\n", repeticoes);
    for(int i=0;i<repeticoes;i++){
        if(i==0){
            seno+=angulo;
        }
        else{
            if(i%2==0){
                seno+=exp(angulo,num_fat)/fat(num_fat);
                
            }
            else{
                seno-=exp(angulo,num_fat)/fat(num_fat);
                
            }
            //System.out.printf("resultado : %.10f / %.10f\n", exp(angulo,num_fat),fat(num_fat));
            //System.out.printf("exp : %.10f\n", exp(angulo,3));
            num_fat+=2;
    
        }
        System.out.printf("%.10f\n", seno);
    }      
    
    
    
    }

    public static double fat(int numero){
        double fat=1;
        while (numero > 1) { 
            fat *= numero; 
            numero--;
        }
        //System.out.println(fat);
        return fat;
    }
    public static double exp(double numero,int repeticoes){
        //System.out.printf("\nrepericoes: %d\n",repeticoes);
        double resultado=numero;
        for(int i=0;i<repeticoes-1;i++){
            resultado*=numero;
            //System.out.println(resultado);
        }
        return resultado;
    }
}
