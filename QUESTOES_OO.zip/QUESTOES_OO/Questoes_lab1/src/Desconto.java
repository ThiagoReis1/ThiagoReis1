//package QUESTOES;
import java.util.Scanner;;
public class Desconto {
    public static void main(String[] args) {

    Scanner teclado=new Scanner(System.in);
    Double valor=teclado.nextDouble();
    teclado.close();
    if(valor>=200){
        valor=valor*0.95;
    }        
    System.out.printf(("%.2f"), valor);
    }

}
