//package helloworld;
import java.util.Scanner;
public class AreaPoligonoO {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        //System.out.println(valores); // ate aqui OK
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        double vetor[] = new double[tam];

        int tamanho=0;

        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Double.parseDouble(arrayValores[i]);
            System.out.printf("%.2f ",vetor[i]);
            if(tamanho==0 && vetor[i]==-1){
                tamanho=i;
            }
        }
        
        
        System.out.printf("\ntamanho %d\n",tamanho);
        double aux1 []=new double[tamanho];
        double aux2 []=new double[tamanho];
        
        int troca=0;

        for(int i=0,j=0;i<tam;i++){
            if(vetor[i]!=-1 && troca==0){
                aux1[i]=vetor[i];
                
                //1 2 3 4 5 -1 1 2 3 1 1 -1
            }
            else if(vetor[i]!=-1 && troca==1){

                
                aux2[j]=vetor[i];
                j++;
                
            }
            else if(vetor[i]==-1){
                troca=1;
            }
        }
            for(int j=0;j<aux1.length;j++){
                System.out.printf("%f ",aux1[j]);
            }
            System.out.printf("\n\n");
            for(int k=0;k<aux2.length;k++){
                System.out.printf("%f ",aux2[k]);
            }
 
 
    }
    
}
