//package QUESTOES;
import java.util.Scanner;
import java.math.*;
public class AreaTriangulo {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        int vetor[] = new int[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Integer.parseInt(arrayValores[i]);
            
        }
        if((vetor[0]+vetor[1]>vetor[2]) && (vetor[0]+vetor[2]>vetor[1]) && (vetor[1]+vetor[2]>vetor[0])){
            int Soma=(vetor[0]+vetor[1]+vetor[2])/2;
            double calculo=Soma * (Soma - vetor[0])*(Soma - vetor[1])*(Soma - vetor[2]);
            double Area=Math.sqrt(calculo);
            System.out.printf("%.2f",Area);
        }
        else{
            System.out.println("Triangulo invalido");
        }
               
    }


}
