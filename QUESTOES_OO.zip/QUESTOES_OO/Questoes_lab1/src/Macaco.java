//package QUESTOES;
public class Macaco {
    public static void main(String[] args) {
        System.out.println("  *****  \n(* o o *)\n *  ^  * \n * --- * \n  *****  ");
        
    }
}

