//package QUESTOES;


import java.util.Scanner;

public class IdadeUfam {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int anoAtual = teclado.nextInt();
        teclado.close();
        anoAtual= anoAtual - 1909;
    System.out.printf("A UFAM tem %d anos de fundacao", anoAtual);
    }

   
    
}
