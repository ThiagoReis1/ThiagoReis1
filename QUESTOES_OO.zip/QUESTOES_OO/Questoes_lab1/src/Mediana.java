import java.util.Scanner;

public class Mediana {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        
            String input = teclado.nextLine();
            String[] tokens = input.split(" ");
            int[] numeros = new int[tokens.length];

            
            float mediana = 0;
           

            for (int i = 0; i < tokens.length; i++) {
                String token = tokens[i];
                numeros[i] = Integer.parseInt(token);
                //System.out.printf("%d ", numeros[i]);
            }
            int tamanho=numeros.length-1;
            
            //System.out.printf("\n\ntamanho: %d\n\n", tamanho);
            if(tamanho%2==0){
                mediana=(numeros[tamanho/2]+numeros[(tamanho/2)-1])/2.0f;
                //System.out.printf("Numero 1: %d \n Numero 2: %d\n", numeros[tamanho/2],numeros[(tamanho/2)-1]);
            }
            else{
                mediana=numeros[tamanho/2];
            }
                
            System.out.printf("%.1f", mediana);
        }
                
                    

             
// 2 4 5 7 9 12 15 -1

    }
