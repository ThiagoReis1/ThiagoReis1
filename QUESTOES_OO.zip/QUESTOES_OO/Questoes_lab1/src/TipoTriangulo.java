//package QUESTOES;
import java.util.Scanner;
import java.math.*;
public class TipoTriangulo {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        double vetor[] = new double[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Double.parseDouble(arrayValores[i]);
            
        } 
        
        if((vetor[0]+vetor[1]>vetor[2]) && (vetor[0]+vetor[2]>vetor[1]) && (vetor[1]+vetor[2]>vetor[0])){
            if(vetor[0]==vetor[1] && vetor[0]==vetor[2]){
                System.out.println("equilatero");
            }
            else if((vetor[0]==vetor[1] && vetor[0]!=vetor[2]) || (vetor[1]==vetor[2] && vetor[0]!=vetor[2]) ||(vetor[0]==vetor[2] && vetor[0]!=vetor[1])){
                System.out.println("isosceles");
            }
            else{
                System.out.println("escaleno");
            }
        }
        else{
            System.out.println("invalido");
        }

}
}