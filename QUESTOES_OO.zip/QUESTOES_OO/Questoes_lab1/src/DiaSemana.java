import java.util.Scanner;

public class DiaSemana {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        String input = scanner.nextLine();
        String[] tokens = input.split(" ");
        int[] valores = new int[tokens.length];


        //System.out.println("Aqui");

            


        int tamanho_vetor=0;

        int dias_semanas[]={0,0,0,0,0,0,0};
        int aux[]={0,0,0,0,0,0,0};

        // 2 4 3 4 5 8 8 7 3 4 3 3 4 4 3 3 4 3 3 2 2 9 3 4 7 3 4 1 -1

        for (int i = 0,control=0; i < tokens.length-1; i++) {
            String token = tokens[i];
            valores[i] = Integer.parseInt(token);
            if(i%7==0){
                //System.out.println();
            }
            //System.out.printf("%d -> ", valores[i]);
        }
        for(int i=0;i<valores.length;i++){
            if((i-6)%7==0){
                dias_semanas[6]+=valores[i];
            }
            else if((i-5)%7==0){
                dias_semanas[5]+=valores[i];
            }
            else if((i-4)%7==0){
                dias_semanas[4]+=valores[i];
            }
            else if((i-3)%7==0){
                dias_semanas[3]+=valores[i];
            }
            else if((i-2)%7==0){
                dias_semanas[2]+=valores[i];
            }
            else if((i-1)%7==0){
                dias_semanas[1]+=valores[i];
            }
            else if(i%7==0){
                dias_semanas[0]+=valores[i];
            }
        }

        int maior=0;
        //System.out.println();
        for(int i=0;i<dias_semanas.length;i++){
            //System.out.printf("%d[%d] ->", dias_semanas[i],i);
            if((dias_semanas[i]>maior) ||( i==0)){
                maior=dias_semanas[i];
            }
        }
        //System.out.printf("\n\nMaior = %d\n\n",maior);
        for(int i=0;i<dias_semanas.length;i++){
            //System.out.printf("%d[%d] ->", dias_semanas[i],i);
            if(maior==dias_semanas[i]){
                System.out.println(i+1);
            }
        }      
 

        

    }
}
                