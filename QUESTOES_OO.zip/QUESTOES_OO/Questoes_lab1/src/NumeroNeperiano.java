//package Questoes_lab1.src;
import java.util.Scanner;
public class NumeroNeperiano {
    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    int numero=teclado.nextInt();
    double resultado=0;
    double fat;
    for(int i=0;i<numero;i++){
        resultado+=1.0/fat(i);
    }      
    System.out.printf("%.6f", resultado);
    }


    public static int fat(int numero){
        int fat=1;
 
        while (numero > 1) { 
            fat *= numero; 
            numero--;
        }
        return fat;
    }
}
