//package QUESTOES;
import java.util.Scanner;
public class AsciiArt{
    
    public void func (){
        
        Scanner teclado = new Scanner(System.in);
        //System.out.println("Digite um numero:");
        int base__asteriscos = teclado.nextInt();
        teclado.close();
        String espaco="";
        
        
            
       
       
        

        for(int i=base__asteriscos;i>0;i--){


           if(i!=base__asteriscos){
            espaco+="  ";
            
            
            }
               
                System.out.printf("%s%s%s\n", imprimir(i),espaco,imprimir(i));
                
            }
        }
        
        public String imprimir(int r){
            String aux="";
        
            for(int i=0;i<r;i++){
                aux+="*";}
            return aux;
        }
    
    public static void main (String[] args) {
        AsciiArt ff= new AsciiArt();
        ff.func();
    }
}

