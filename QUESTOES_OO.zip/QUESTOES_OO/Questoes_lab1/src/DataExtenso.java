import java.util.Scanner;

public class DataExtenso {

    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        String data = teclado.nextLine();
        String[] meses = {"janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"};
        String de ="de";
        
        teclado.close();
        //21102015
        int dia = Integer.parseInt(data.substring(0, 2));
        int mes = Integer.parseInt(data.substring(2, 4)) - 1; //ajuste para o índice do vetor
        int ano = Integer.parseInt(data.substring(4));

        System.out.printf("%d %s %s %s %d", dia, de, meses[mes], de, ano);
    }
    
}