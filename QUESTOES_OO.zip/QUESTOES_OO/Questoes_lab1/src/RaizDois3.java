import java.util.Scanner;
public class RaizDois3 {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int repeticoes=teclado.nextInt();
        double saida=0;

       // double rec=(2.0+1.0);
       // double ciclico=1.0/(2.0+1.0/rec);
         //ciclico=1.0/(2.0+1.0/(2.0+1.0));
         //ciclico=1.0/(2.0+1.0/(2.0+1.0/(2.0+1.0)));
        for(double i=1.0;i<repeticoes+1;i++){
            saida=1+ 1.0/(2.0+1.0);
            System.out.printf("%.14f\n",saida); 
        }
        //System.out.printf("%.14f",saida); 
    }
    
    }

/*
 * entrada 1
 * saida 1+(1/(2+1))
 * entrada 2
 * saida 1+(1/(2+1/(2+1)))
 * entrada 3
 * saida 1+(1/(2+1/(2+1/(2+1))))
 * 
 * 
 */