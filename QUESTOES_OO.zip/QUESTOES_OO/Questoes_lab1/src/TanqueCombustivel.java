//package QUESTOES;
import java.util.Scanner;
import java.math.*;
public class TanqueCombustivel {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        double vetor[] = new double[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Double.parseDouble(arrayValores[i]);
            
        }
        double raio= vetor[0];
        double altura_ar=vetor[1];
        double opcao= vetor[2];
        double volume_calota=(Math.PI/3.0)*(altura_ar*altura_ar)*(3*raio-altura_ar);
        System.out.printf("\nvolume da calota : %.3f\n", volume_calota);
        if(opcao==2){
            double volume_esfera=(4.0/3.0)*Math.PI*(raio*raio*raio)-volume_calota;
            System.out.printf("%.4f", volume_esfera);
        }
        else{
            //double volume_calota=(Math.PI/3.0)*(altura_ar*altura_ar)*(3*raio-altura_ar);
            System.out.printf("%.4f", volume_calota);
        }
        
        
        
}
}