import java.util.Scanner;

public class ContaEnergia{

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        //System.out.println(arrayValores[1]);
        double consumo= Double.parseDouble(arrayValores[0]);
        String opcao=arrayValores[1];

        //System.out.println(opcao.contentEquals("R"));
        if(consumo>=0){
            if(opcao.contentEquals("R")){
                if(consumo>500){
                    consumo*=0.65;
                }
                else{
                    consumo*=0.40;
                }
            }
            else if(opcao.contentEquals("C")){
                if(consumo<=1000){
                    consumo*=0.55;
                }
                else{
                    consumo*=0.60;
                }
            }
            else if (opcao.contentEquals("I")){
                if(consumo<=5000){
                    consumo*=0.55;
                }
                else{
                    consumo*=0.60;
                }
            }
            else{
                consumo=-1.0;
            }
        }
        else{
            consumo=-1.0;
        }
        System.out.printf("%.2f", consumo);
}
}