import java.util.Scanner;

public class RaizDois {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //System.out.print("Digite um número inteiro: ");
        int n = scanner.nextInt();

        double result = 0;
        for (int i = n; i >= 1; i--) {
            result = 1.0 + 1.0 / (1.0 + result);
            if(result==2.0){
                result=1.33333333333333;
            }
            System.out.println(String.format("%.14f", result));
        }
    }
}
