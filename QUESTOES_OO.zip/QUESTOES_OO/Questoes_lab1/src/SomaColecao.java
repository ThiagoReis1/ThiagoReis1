//package Questoes_lab1.src;


import java.util.Scanner;
public class SomaColecao {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length-1;
        int vetor[] = new int[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Integer.parseInt(arrayValores[i]);
            
        }
        
        int soma=0;
        
        
        for(int i=0;i<tam;i++){
                //System.out.println(vetor[i]);
                soma+=vetor[i];
               
            }
  
        System.out.printf("%d",soma);      
        }

  
        
        
    }
    

