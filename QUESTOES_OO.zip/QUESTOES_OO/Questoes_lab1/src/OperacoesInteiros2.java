//package helloworld;
import java.util.Scanner;
public class OperacoesInteiros2 {
    public static void main(String[] args) {
        funcao();
    }

    public static void funcao(){
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        
        int tam=arrayValores.length;

        int contra_Erro=0;
        for(int i=0;i<tam;i++){
            if(arrayValores[i].equals("")){
                contra_Erro=1;
            }
           // System.out.printf("asd %s\n", arrayValores[i]);
        }
        int vetor[] = new int[tam];

        
        if(arrayValores[0].isEmpty() || valores.equals("")){
            contra_Erro=1;
        }
        teclado.close();


        //int quantV=-1;
        if(contra_Erro!=1){
        for(int i=0;i<tam;i++){
            //System.out.print(vetor[i]);
                
            
                vetor[i]=Integer.parseInt(arrayValores[i]);
            
                
                
            }
            
            ///if(vetor[i]==-1){
               // quantV++;
            //}   
        
        
        int quant_elem=0;
        int quant_pares=0;
        int quant_impares=0;
        int soma_total=0; 
        int Maior=0;
        int menor=99999999;
        double media=0;
        //int prim=1;

        

        
        for(int i=0,prim=1;i<tam;i++){
            if(vetor[i]!=-1){
                if((vetor[i]>Maior) || prim==1){
                    Maior=vetor[i];
                    prim=0;
                }
                if((vetor[i]<menor) || (prim==1)){
                    menor=vetor[i];
                    prim=0;
                }

                if(vetor[i]%2==0){
                    quant_pares++;
                }
                if (vetor[i]%2==1){
                    quant_impares++;
                    //System.out.printf("achei%d\n", quant_impares);
                }
                soma_total+=vetor[i];
                quant_elem++;

                //System.out.printf("%d\n", menor);
                
            }

            else{

                if(quant_elem!=0){
                    System.out.printf("%d\n", quant_elem);
                    System.out.printf("%d\n", quant_pares);
                    System.out.printf("%d\n", quant_impares);
                    System.out.printf("%d\n", soma_total);
                    float aux=quant_elem;
                    media=soma_total/ aux;
                    System.out.printf("%.2f\n", media);
                    System.out.printf("%d\n", Maior);
                    System.out.printf("%d\n", menor);
                }

                quant_elem=0;
                quant_pares=0;
                quant_impares=0;
                soma_total=0;
                media=0;
                Maior=0;
                menor=999999999;
                prim=1;
            }
            //System.out.printf("%d ", vetor[i]);
            

            

             



            // 1 5 2 8 4 -1 10 54 23 78 -1 -1
        }

        //System.out.printf("\nQuantidade de vetores : %d ", quantV);
        
    }
}
}


/*
Quantidade de elementos
Quantos são pares
Quantos são ímpares
Soma total
Média (duas casas decimais)
Maior
Menor 
 
 */
/*
5 Quantidade de elementos
3 pares
2 ímpares
20 Soma total
4.00 Média 
8 Maior
1 Menor 
4
3
1
165
41.25
78
10
 */