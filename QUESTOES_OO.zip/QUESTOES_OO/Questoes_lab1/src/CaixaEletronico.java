//package QUESTOES;
import java.util.Scanner;
public class CaixaEletronico {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int valor= teclado.nextInt();
        teclado.close();
        int q_50=0;
        int q_10=0;
        int q_2=0;
        if(valor<=0 || valor%2==1){
            System.out.println("Valor Invalido");
        }
        else{
            while(valor>=50){
                valor=valor-50;
                q_50++;
     
                //System.out.println(valor+"\n");
            };

            while(valor>=10){
                valor=valor-10;
                q_10++;
            };

            while(valor>=2){
                valor=valor-2;
                q_2++;
            };
            String aux="";
            
            if(q_50>0){
                System.out.printf("%d notas de R$50",q_50);
                
            }
            if(q_10>0){
                if(q_50 > 0 && q_2>0){
                    aux=", ";
                    
                }


                else if (q_50 > 0){
                    aux=" e ";
                    
                }
                System.out.printf("%s%d notas de R$10",aux,q_10);
            }
            if(q_2>0){
                if(q_50<0 && q_10>0){
                    aux="";
                }
                else {
                    aux=" e ";
                }
                    
                
                System.out.printf("%s%d notas de R$2",aux,q_2);
            }
           // System.out.printf("%d notas de R$50, %d notas de R$10 e %d notas de R$2", args)
        }

    }
    
}
