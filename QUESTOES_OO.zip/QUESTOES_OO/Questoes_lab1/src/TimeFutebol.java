import java.util.Scanner;

public class TimeFutebol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        String input = scanner.nextLine();
        String[] tokens = input.split(" ");
        int[] valores = new int[tokens.length];




            
        int vitorias = 0;
        int empates = 0;
        int derrotas = 0;

        int tamanho_vetor=0;

        

        for (int i = 0,control=0; i < tokens.length; i++) {
            String token = tokens[i];
            valores[i] = Integer.parseInt(token);
            if (valores[i]==-1 && control==0){
                tamanho_vetor=i;
                control=1;
            }
        }

       // System.out.printf("\n\n\n\n Tamanho do vetor: %d\n\n\n\n", tamanho_vetor);
        //System.out.printf("\n\n\n\n Tamanho do vetor String: %d\n\n\n\n", tokens.length);
        int[] vet1 = new int[tamanho_vetor];
        int[] vet2 = new int[tamanho_vetor];

        int vet1C=0;
        

        for(int i=0,j=0;i<valores.length;i++){
            if(valores[i]!=-1 && vet1C==0){
                vet1[i]=valores[i];
                //System.out.printf("Adiconando o valor[vet1]: %d\n", vet1[i]);
            }
            else if(valores[i]!=-1 && vet1C==1){
                vet2[j]=valores[i];
               // System.out.printf("Adiconando o valor[vet1]: %d\n", vet2[i]);
                j++;
            }

            else if(valores[i]==-1){
                vet1C=1;
            }
        }

        /* 
        for(int i=0;i<tamanho_vetor;i++){
            System.out.printf("%d ->", vet1[i]);
        }
        System.out.println();
        for(int i=0;i<tamanho_vetor;i++){
            System.out.printf("%d ->", vet2[i]);
        }
          */

        for(int i=0;i<tamanho_vetor;i++){
            if(vet1[i]>vet2[i]){
                vitorias++;
            }
            else if(vet1[i]<vet2[i]){
                derrotas++;
            }
            else{
                empates++;
            }
        } 

        System.out.printf("%d %d %d",vitorias,empates,derrotas);

    }
}
                