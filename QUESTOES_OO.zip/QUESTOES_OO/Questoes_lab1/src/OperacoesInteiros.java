import java.util.Scanner;

public class OperacoesInteiros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            String input = scanner.nextLine();
            String[] tokens = input.split(" ");
            int[] numbers = new int[tokens.length];
            int count = 0;
            int sum = 0;
            int max = Integer.MIN_VALUE;
            int min = Integer.MAX_VALUE;
            int evenCount = 0;
            int oddCount = 0;

            for (int i = 0; i < tokens.length; i++) {
                String token = tokens[i];
                if (token.isEmpty()) {
                    continue; // Ignora strings vazias
                }

                try {
                    numbers[i] = Integer.parseInt(token);
                } catch (NumberFormatException e) {
                    System.out.println("Entrada inválida: " + token);
                    break; // Sai do loop quando encontrar entrada inválida
                }

                if (numbers[i] == -1) {
                    if (count == 0) {
                        break; // Ignora vetores vazios
                    }

                    System.out.println("" + count);
                    System.out.println("" + evenCount);
                    System.out.println("" + oddCount);
                    System.out.println("" + sum);
                    System.out.printf("%.2f\n", (double) sum / count);
                    System.out.println("" + max);
                    System.out.println("" + min);

                    count = 0;
                    sum = 0;
                    max = Integer.MIN_VALUE;
                    min = Integer.MAX_VALUE;
                    evenCount = 0;
                    oddCount = 0;
                } else {
                    count++;
                    sum += numbers[i];

                    if (numbers[i] > max) {
                        max = numbers[i];
                    }

                    if (numbers[i] < min) {
                        min = numbers[i];
                    }

                    if (numbers[i] % 2 == 0) {
                        evenCount++;
                    } else {
                        oddCount++;
                    }
                }
            }

            if (count == 0) {
                break; // Sai do loop quando encontrar vetor vazio
            }
        }
    }
}