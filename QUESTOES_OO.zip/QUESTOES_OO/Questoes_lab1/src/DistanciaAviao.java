import java.util.Scanner;

public class DistanciaAviao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        String input = scanner.nextLine();
        String[] tokens = input.split(" ");
        int[] valores = new int[tokens.length];
        

        //System.out.println("Aqui");

        int matriz[][]={
        {0 ,2 ,11,6 ,15,11,1},
        {2 ,0 ,7 ,12,4 ,2 ,15},
        {11,7 ,0 ,11,8 ,3 ,13},
        {6 ,12,11,0 ,10,2 ,1},
        {15,4 ,8 ,10,0 ,5 ,13},
        {11,2 ,3 ,2 ,5 ,0 ,14},
        {1 ,15,13,1 ,13,14,0}}; 

        /* 
        --- 111 222 333 444 555 666 777
        111	 00	 02	 11	 06	 15	 11	 01
        222	 02	 00	 07	 12	 04	 02	 15
        333	 11	 07	 00	 11	 08	 03	 13
        444	 06	 12	 11	 00	 10	 02	 01
        555	 15	 04	 08	 10	 00	 05	 13
        666	 11	 02	 03	 02	 05	 00	 14
        777	 01	 15	 13	 01	 13	 14	 00
        */

        // 2 4 3 4 5 8 8 7 3 4 3 3 4 4 3 3 4 3 3 2 2 9 3 4 7 3 4 1 -1

        for (int i = 0; i < tokens.length-1; i++) {
            String token = tokens[i].substring(0, 1);
            valores[i] = Integer.parseInt(token)-1;
            if(i%7==0){
                //System.out.println();
            }
            //System.out.printf("%s -> ",tokens[i].substring(0, 1));
            //System.out.printf("%d -> ", valores[i]);
        }
        int total=0;
        

        //System.out.printf("\n");
        for(int i=0;i<valores.length-2;i++){
            
            total+=matriz[valores[i]][valores[i+1]];
            //System.out.printf("%d + ",matriz[valores[i]][valores[i+1]]);
        }
        System.out.printf("%d",total);
        }

  
 
    }
        


                