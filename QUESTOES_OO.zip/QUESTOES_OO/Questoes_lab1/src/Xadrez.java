//package QUESTOES;
import java.util.Scanner;
public class Xadrez {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int repeticoes= teclado.nextInt();
        teclado.close();
        String aux="*";
        for(int i=0;i<repeticoes;i++){
            System.out.printf("\n");
            if(i%2==1){
                System.out.printf(" ");
            }
            for(int j=0;j<repeticoes;j++){

                System.out.printf("%s ", aux);
            }

        }      
    }


}
