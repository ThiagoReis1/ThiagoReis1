//package QUESTOES;
import java.util.Scanner;
public class SomaDigitos{//package QUESTOES;

    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);

        int valores=teclado.nextInt();
        teclado.close();
        String valores_string=Integer.toString(valores);
        
        int tamanho=valores_string.length();
   
        int soma=0;
        for(int i =0;i<tamanho;i++) {
           char valor_char=Integer.toString(valores).charAt(i);
           int valor = + Integer.parseInt(String.valueOf(valor_char));
           soma+=valor;
        }
       
        System.out.println(soma);
       

               
    }


}
