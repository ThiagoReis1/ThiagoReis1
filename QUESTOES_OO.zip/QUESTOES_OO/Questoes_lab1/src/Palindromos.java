import java.util.Scanner;

public class Palindromos {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String linha = teclado.nextLine();
        linha = linha.toUpperCase().replaceAll(" ", "");
        StringBuilder textoLimpo = new StringBuilder();
        for (int i = 0; i < linha.length(); i++) {
            char letra = linha.charAt(i);
            if (Character.isLetter(letra)) {
                textoLimpo.append(letra);
            }
            
        }
        String saida_texto=textoLimpo.toString();
        
        //System.out.printf("textoLimpo: %s\n\n\n",textoLimpo);
        String textoReverso = textoLimpo.reverse().toString();
        
        //System.out.printf("textoLimpo: %s\n\n\n",textoLimpo.reverse());
        String texto = textoLimpo.reverse().toString();
       // System.out.printf("textoReverso: %s\n\n\n",textoReverso);
        //System.out.printf("texto: %s\n\n\n",texto);

        


        
        if (texto.equals(textoReverso)) {
            System.out.printf(saida_texto + " 1");
        } else {
            System.out.printf(saida_texto + " 0");
        }
    }
}