//package QUESTOES;
import java.util.Scanner;
import java.math.*;
public class RotaOrtodromica {
 
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        Double vetor[] = new Double[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Double.parseDouble(arrayValores[i]);
            //System.out.println(vetor[i]);
            
        }
        int R=6371;

        double t1=Math.toRadians(vetor[0]);
        double g1=Math.toRadians(vetor[1]);
        double t2=Math.toRadians(vetor[2]);
        double g2=Math.toRadians(vetor[3]);

        //toRadians(double angdeg)
        //double radians = Math.toRadians(45);
        //seno – Math.sin(double a), cosseno – Math.cos(double a) e arco cosseno – Math.acos(double a).
        
        double distacia=R*Math.acos(Math.sin(t1)*Math.sin(t2)+Math.cos(t1)*Math.cos(t2)*Math.cos(g1-g2));
        System.out.printf("A distancia entre os pontos (%.6f, %.6f) e (%.6f, %.6f) e de %.2f km", vetor[0],vetor[1],vetor[2],vetor[3],distacia);

}
}
