//package QUESTOES;
import java.util.Scanner;
public class PontoReta {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        Double vetor[] = new Double[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Double.parseDouble(arrayValores[i]);
            //System.out.println(vetor[i]);
          
        }    
        String resultado;
        if(2*vetor[0] + vetor[1] == 3){
            resultado="pertence a reta 2x + y = 3.";
        }
        else{
            resultado="nao pertence a reta 2x + y = 3.";
        }
        System.out.printf("Ponto (%s, %s) %s",vetor[0].toString(),vetor[1].toString(),resultado);
}
}