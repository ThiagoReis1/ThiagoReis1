import java.util.Scanner;

public class AreaPoligono {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores = teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam = arrayValores.length;

        double aux1[] = new double[tam / 2];
        double aux2[] = new double[tam / 2];

        int pos = 0;
        for (int i = 0; i < tam; i++) {
            if (Double.parseDouble(arrayValores[i]) == -1) {
                pos = i;
                break;
            }
            aux1[i] = Double.parseDouble(arrayValores[i]);
        }
        for (int i = pos + 1, j = 0; i < tam; i++, j++) {
            aux2[j] = Double.parseDouble(arrayValores[i]);
        }

        double sum = 0.0;
        for (int i = 0; i < aux1.length - 1; i++) {
            sum += (aux1[i] * aux2[i + 1]) - (aux2[i] * aux1[i + 1]);
        }
        sum += (aux1[aux1.length - 1] * aux2[0]) - (aux2[aux2.length - 1] * aux1[0]);

        double area = 0.5 * Math.abs(sum);
        System.out.printf("%.4f", area);
    }
}