

import java.util.Scanner;
import java.math.*;
public class RaizQuadrada {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double numero= teclado.nextInt();
        teclado.close();
        double raiz = Math.sqrt(numero);
        System.out.printf("%.4f", raiz);
    }

}
