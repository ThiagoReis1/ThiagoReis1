import java.util.Scanner;;
public class CifraCesar{
public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    String texto = scan.nextLine();
    int deslocamento = Integer.parseInt(texto.split(" ")[0]);
    String textoLimpo = texto.substring(texto.indexOf(" ") + 1).toUpperCase();
    String alfabetoCifrado = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String alfabetoOriginal = alfabetoCifrado.substring(deslocamento) + alfabetoCifrado.substring(0, deslocamento);

    StringBuilder textoCifrado = new StringBuilder();

    for (int i = 0; i < textoLimpo.length(); i++) {
        char letra = textoLimpo.charAt(i);

        if (letra >= 'A' && letra <= 'Z') {
            int posicao = alfabetoCifrado.indexOf(letra);
            char cCifrado = alfabetoOriginal.charAt(posicao);
            textoCifrado.append(cCifrado);
        } else {
            textoCifrado.append(letra);
        }
    }

    System.out.println(textoCifrado);
}
}