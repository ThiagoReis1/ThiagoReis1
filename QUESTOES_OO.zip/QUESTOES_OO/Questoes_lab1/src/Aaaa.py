class RaizDois:
    @staticmethod
    def fracao_continua(n):
        x = 1.0
        for i in range(n):
            x = 1.0 + 1.0 / (1.0 + x)
            yield x
    
    @staticmethod
    def calcular_raiz_dois(n):
        for i, x in enumerate(RaizDois.fracao_continua(n)):
            print(f"{i+1}: {x:.14f}")
    
if __name__ == '__main__':
    n = int(input("Digite o valor de N: "))
    RaizDois.calcular_raiz_dois(n)