import java.util.Scanner;
public class AproximacaoPi {
    
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int aproximacao= teclado.nextInt();
        double valor_Pi=0;

        double a=2;
        double b=3;
        double c=4;
        double decimal=0;
        for(int i =0;i<aproximacao;i++){
            if(i==0){
                valor_Pi=3;
                //System.out.printf("valor de c: %d\n",c);
                
            }
            else{

            
            if(i%2==1){
                decimal=4.0/(a*b*c);
                valor_Pi+=decimal;
                //System.out.printf("%.6f\n", decimal);
                //System.out.printf("valor:%.6f\n", (quatro/(a*b*c)));
            }
            else if(i%2==0){
                decimal=4.0/(a*b*c);
                valor_Pi-=decimal;
            }
                a+=2.0;
                b+=2.0;
                //System.out.printf("valor de c: %d\n",c);
                c+=2.0;
                //System.out.printf("valor de c: %d ",c);
            }
            //System.out.printf("valor de c: %d\n ",c);
           // System.out.printf("resultado=%.6f\n a=%d b=%d c=%d\n", decimal,a,b,c);
           
          // System.out.printf("\nRepetição %d\n", i);
           //System.out.printf("valores de a=%d b=%d c=%d\n", a,b,c);
           //System.out.printf("operação: 4.0/(%d * %d * %d)\n", a,b,c);
           //System.out.printf("decimal gerado %f\n", decimal);
            System.out.printf("%.6f\n", valor_Pi);

        }
    }
    
        
    
}
