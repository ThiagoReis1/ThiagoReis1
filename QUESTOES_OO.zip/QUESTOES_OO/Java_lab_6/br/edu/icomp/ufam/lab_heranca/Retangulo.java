package br.edu.icomp.ufam.lab_heranca;

public class Retangulo extends FormaGeometrica {
    
    public double largura;
    public double altura;
    public	Retangulo(int posX, int posY,double largura, double altura){
    
        super(posX,posY);
        this.largura=largura;
        this.altura=altura;
    }
    public double	getArea(){
        double area =this.altura*this.largura;
        return area;
    }
    public double	getPerimetro(){
        double perimetro = 2 * (this.altura + this.largura);
        return perimetro;
    }
    
    public String	toString(){
        String aux= String.format("Retângulo na %s com largura de %.1fcm e altura de %.1fcm (área=%scm2, perímetro=%scm)",
         super.getPosString(),this.largura,this.altura,Double.toString( this.getArea()),Double.toString(this.getPerimetro()));
        return aux;
    }    
}
