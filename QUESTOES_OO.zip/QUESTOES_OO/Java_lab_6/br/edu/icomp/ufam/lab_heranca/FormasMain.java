package br.edu.icomp.ufam.lab_heranca;

public class FormasMain {
    public static void main(String[] args) {
        FormaGeometrica vetor[] ;
        Circulo circulos= new Circulo(0, 0, 0);
        Quadrado quadrados=new Quadrado(0, 0, 0);
        Retangulo retangulos= new Retangulo(0, 0, 0, 0);

       
            
        
    }
}
