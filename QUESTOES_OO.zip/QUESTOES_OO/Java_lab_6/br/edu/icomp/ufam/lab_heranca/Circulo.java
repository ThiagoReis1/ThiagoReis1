package br.edu.icomp.ufam.lab_heranca;

public class Circulo extends FormaGeometrica{
    public	double raio; 
    public	Circulo(int posX, int posY, double raio){
    
        super(posX,posY);
        this.raio=raio;
    }
    public double	getArea(){
        double area =(this.raio*this.raio) * Math.PI;
        return area;
    }
    public double	getPerimetro(){
        double perimetro = 2 * Math.PI * this.raio;
        return perimetro;
    }
    
    public String	toString(){
        String aux= String.format("Círculo na %s com raio de %.1fcm (área=%scm2, perímetro=%scm)",
         super.getPosString(),this.raio,Double.toString( this.getArea()),Double.toString(this.getPerimetro()));
        return aux;
    }
}
