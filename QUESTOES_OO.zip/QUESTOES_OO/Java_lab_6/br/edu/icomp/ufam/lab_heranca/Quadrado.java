package br.edu.icomp.ufam.lab_heranca;

public class Quadrado  extends Retangulo{

    public double lado;
    
    public	Quadrado(int posX, int posY,double lado){
    
        super(posX, posY,lado,lado);
        this.lado=lado;
        
    }
        
    
    public String	toString(){
        
        String aux= String.format("Quadrado na %s com lado de %.1fcm (área=%scm2, perímetro=%scm)",
         super.getPosString(),this.lado,Double.toString( this.getArea()),Double.toString(this.getPerimetro()));
        return aux;
    }     
}
