public class SessaoJediMain {
    //IniciadoJedi novo;
    public static void main(String[] args) {
        IniciadoJedi novo= new IniciadoJedi();
       System.out.println(novo.getClass());
    }
}
