import java.util.ArrayList;

public class SessaoJedi {
    String nome;
    TreinadorJedi treinador; 
    ArrayList<IniciadoJedi> iniciados= new ArrayList<IniciadoJedi>();

    SessaoJedi(String nome, TreinadorJedi treinador){
        this.nome=nome;
        this.treinador=treinador;
    }
    public void	addIniciado(IniciadoJedi iniciado){
        if(iniciados.contains(iniciado)){
            return;
        }
        iniciados.add(iniciado);
    }
        
    
    public IniciadoJedi getIniciado(String nome){
        for(IniciadoJedi jedi:this.iniciados){
            if(jedi.nome.equals(nome)){
                return jedi;
            }
        }

        return null;
    }
    public double getMediaAnoNascimento(){
        double media=0;
        double cont=0;
        for(IniciadoJedi jedi:this.iniciados){
            media+=jedi.anoNascimento;
            cont++;
        }
        return media/cont;
    }
    public String getDescricao(){
        StringBuilder aux=new StringBuilder();
        int i=1;
        aux.append("--> SESSÃO ").append(this.nome).append(" (Treinador: ").append(treinador.getDescricao()).append(")").append("\n");
        for(IniciadoJedi jedi:this.iniciados){
            aux.append("- Iniciado ").append(i).append(": ").append(jedi.getDescricao()).append("\n");
            i++;
        }
        return aux.toString();
    }
}
