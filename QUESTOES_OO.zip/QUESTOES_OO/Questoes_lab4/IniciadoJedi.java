import static java.lang.Math.*;

public class IniciadoJedi{
    String nome; 
    String especie; 
    int anoNascimento;

    IniciadoJedi(){}
    IniciadoJedi(String nome, String especie, int anoNascimento){
        this.nome=nome;
        this.especie=especie;
        this.anoNascimento=anoNascimento;
        }
   public String getDescricao(){
        StringBuilder aux= new StringBuilder();
        aux.append(this.nome);
        aux.append(" (especie=").append(this.especie);
        aux.append(", nascimento=").append(getAnoNascimento()).append(")");
        

        return aux.toString();
   }
    public String getAnoNascimento(){
        String aux[]={"ABY","DBY"};
        if(this.anoNascimento<0){
            return abs(this.anoNascimento)+" "+aux[0];
        }
        return   this.anoNascimento +" "+aux[1];
        
    }
}