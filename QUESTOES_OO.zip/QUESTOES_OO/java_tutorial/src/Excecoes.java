public class Excecoes {
    
}
