//package helloworld;
import java.util.Scanner;
public class PorcentagemAcerto {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String valores=teclado.nextLine();
        String[] arrayValores = valores.split(" ");
        int tam=arrayValores.length;
        int vetor[] = new int[tam];
        teclado.close();
        for(int i=0;i<tam;i++){
            vetor[i]=Integer.parseInt(arrayValores[i]);
            
        }
        
        int pos=0;
        int tamanho=(vetor.length-2)/2;
        int aux1 []=new int[tamanho];
        int aux2 []=new int[tamanho];
        for(int i=0;i<tam;i++){
            if(vetor[i]!=-1 && pos==0){
                aux1[i]=vetor[i]; 
                //1 2 3 4 5 -1 1 2 3 1 1 -1
            }
            else if(vetor[i]==-1 && pos==0){
                i++;
                aux2[pos]=vetor[i];
                pos++;
            }
            else if(vetor[i]!=-1){
                aux2[pos]=vetor[i];
                pos++;
            }
              
        }
        /*for(int i=0;i<tamanho;i++){
            
            System.out.println("vetor 1: " + aux1[i]);
            
        }
        for(int i=0;i<tamanho;i++){
            
            
            System.out.println("vetor 2: " + aux2[i]);
        }
        */
        float acertou=0;
        for(int i=0;i<tamanho;i++){
            if(aux1[i]==aux2[i]){
                acertou++;
            }
        }
        float porcentagem= (acertou*100/tamanho);
        System.out.printf("%.2f" ,porcentagem);
    }
    
}