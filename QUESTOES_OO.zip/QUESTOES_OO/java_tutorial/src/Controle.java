import java.util.List;
public class Controle {
    public double media(List<Integer> valores) throws ValorInvalidoException{
        int soma=0;
        if(valores==null || valores.size()==0) {
            throw new ValorInvalidoException("Valor invalido!");
        }
        else{
        for(int valor : valores){
            soma+=valor;
        }
        return (float)soma/valores.size();
        }
    }
}
