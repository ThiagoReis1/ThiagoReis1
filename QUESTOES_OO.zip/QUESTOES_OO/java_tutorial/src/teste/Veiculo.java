package teste;

public abstract class Veiculo {
    private int VelocidadeMax;
    Veiculo(){}
    Veiculo(int VelocidadeMax){
        this.VelocidadeMax=VelocidadeMax;
    }
    public void VelocidadeMax(){
        System.out.printf("Velocidade Maxima: %d\n", this.VelocidadeMax);
    }
}
