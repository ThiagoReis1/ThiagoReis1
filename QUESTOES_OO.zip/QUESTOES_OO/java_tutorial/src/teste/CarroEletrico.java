package teste;

public class CarroEletrico extends Carro {
    private int Bateria;

    public CarroEletrico(int Quantportas,String Cor,String Placa,String Modelo,int Bateria,int VelocidadeMax){
        super(Quantportas,Cor,Placa,Modelo,VelocidadeMax);
        this.Bateria=Bateria;
    }
    public void Informacoes(){
        
        super.Informacoes();
        System.out.printf("Bateria: %d\n",this.Bateria);
        
        
    }
    
    
}
