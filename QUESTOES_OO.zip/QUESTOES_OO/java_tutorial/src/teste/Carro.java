package teste;

public class Carro extends Veiculo{
    private int Quantportas;
    private String Cor;
    private String Placa;
    private String Modelo;

    Carro(){}
    public Carro(int Quantportas,String Cor,String Placa,String Modelo,int VelocidadeMax){
        super(VelocidadeMax);
        this.Quantportas=Quantportas;
        this.Cor=Cor;
        this.Placa=Placa;
        this.Modelo=Modelo;
    }
    public void Informacoes(){
        System.out.printf("Modelo: %s \n Cor: %s\n Quantidade de Portas:%d\n Placa:%s\n", this.Modelo,this.Cor,this.Quantportas,this.Placa);
        super.VelocidadeMax();
    }

}
