
import teste.Carro;
import teste.CarroEletrico;
//import teste.Veiculo;


public class Main {
    public static void main(String[] args) {
        //public,private,protected
        //Veiculo a = new Veiculo(250); um objeto do tipo abstract não pode ser instanciado,ele é usado para construir objetos base(que são genericos demais)
        Carro c = new Carro(4,"Verde","ACD-123","Fusca",200);
        CarroEletrico ce = new CarroEletrico(4,"Verde","ACD-123","Fusca",2000,150);
        c.Informacoes();
        System.out.println("\n");
        ce.Informacoes();        
    }

}
