package Polimorfismo;

import java.util.ArrayList;
import java.util.List;

public class Fila<Tipo1> {
    private List<Tipo1> itens;
    public Fila(){
        this.itens = new ArrayList<Tipo1>();
    }

    public void adicionar(Tipo1 item){
        this.itens.add(item);
    }
    public Tipo1 remover(){
        if(this.itens.size()>0){
            Tipo1 item = this.itens.get(0);
            this.itens.remove(0);
            return item;
        }
        else{
            System.out.println("lista vazia!");
            return null;
        }
    }
}
