
public class ValorInvalidoException extends Exception{
    private static final long serialVersionUID=55555551313202020L;
    public ValorInvalidoException(String messange){
        super(messange);
    }
}
