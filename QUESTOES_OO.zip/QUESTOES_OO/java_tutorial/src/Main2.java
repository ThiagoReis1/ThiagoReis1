
import Polimorfismo.Fila;
//import teste.Veiculo;


public class Main2 {
    public static void main(String[] args) {
        Fila<String> listaStr = new Fila<>();
        listaStr.adicionar("Mario");
        listaStr.adicionar("Luigi");
        System.out.println(listaStr.remover());
        System.out.println(listaStr.remover());
    }

}
