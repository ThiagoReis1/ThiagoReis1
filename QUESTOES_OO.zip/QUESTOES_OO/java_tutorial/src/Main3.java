import java.util.List;
import java.util.ArrayList;
public class Main3 {
    public static void main(String[] args) {
        Controle ctr =new Controle();
        
        List<Integer> numeros = new ArrayList<>();
        numeros=null;
        try{
            System.out.println(ctr.media(numeros));
        }
        catch(ValorInvalidoException e){
            System.out.println(e.getMessage());
        }
        finally{
            System.out.println("Exucução do Finally!");
        }
        
    }
 /**
  @author Thiago
  @version 1.25
  @since 25.05.23
   */  
}
