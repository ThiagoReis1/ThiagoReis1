import java.util.ArrayList;

public class Ensalamento {
    public ArrayList<Sala> salas = new ArrayList<Sala>();
    public ArrayList<Turma> turmas = new ArrayList<Turma>();
    public ArrayList<TurmaEmSala> ensalamento = new ArrayList<TurmaEmSala>();


    int Total_Salas= 0;
    int Total_Turmas= 0;
    int Turmas_Alocadas= 0;
    int Espaços_Livres= 0;
    int espaco_livre=0;

    int espaco_livre_total=0;
    public void addSala(Sala sala) {
        Total_Salas++;
        salas.add(sala);
    }
    
    public void addTurma(Turma turma) {
        Total_Turmas++;
        turmas.add(turma);
    }
    
    public Sala getSala(Turma turma) {
        for (TurmaEmSala tes : ensalamento) {
            if (tes.turma.equals(turma)) {
                return tes.sala;
            }
        }
        return null;
    }
    
    public boolean salaDisponivel(Sala sala, int horario) {
        for (TurmaEmSala tes : ensalamento) {
            if (tes.sala.equals(sala) && tes.turma.horarios.contains(horario)) {
                return false;
                // tes.turma.numAlunos;
                
            }
        }
        return true;
    }
    
    public boolean salaDisponivel(Sala sala, ArrayList<Integer> horarios) {
        for (Integer horario : horarios) {
            if (!salaDisponivel(sala, horario)) {
                return false;
            }
        }
        return true;
    }
    
    public boolean alocar(Turma turma, Sala sala) {
        if (!turma.acessivel || !sala.acessivel || turma.numAlunos > sala.capacidade || !salaDisponivel(sala, turma.horarios)) {
            return false;
        }
        Turmas_Alocadas++;
        espaco_livre=sala.capacidade-turma.numAlunos;
        espaco_livre_total+=espaco_livre;
        espaco_livre=0;
        ensalamento.add(new TurmaEmSala(turma, sala));
        return true;
    }
    
    public void alocarTodas() {
        int totalTurmasAlocadas = 0;
        for (Turma turma : turmas) {
            boolean turmaAlocada = false;
            for (Sala sala : salas) {
                if (alocar(turma, sala)) {
                    turmaAlocada = true;
                    totalTurmasAlocadas++;
                    break;
                }
            }
            if (!turmaAlocada) {
                System.out.println("Não foi possível alocar a turma " + turma.nome);
            }
        }
        System.out.println(totalTurmasAlocadas + " turmas foram alocadas em salas com sucesso.");
    }
    
    public int getTotalTurmasAlocadas() {
        int totalTurmasAlocadas = 0;
        for (Turma turma : turmas) {
            if (getSala(turma) != null) {
                totalTurmasAlocadas++;
            }
        }
        return totalTurmasAlocadas;
    }
    
    public int getTotalEspacoLivre() {
        //int totalEspacoLivre = 0;
        return  espaco_livre_total;
       // return ensalamento.size();
        
    }

    public String relatorioResumoEnsalamento(){
        StringBuilder aux=new StringBuilder();
        aux.append("Total de Salas: ").append(Total_Salas).append("\n");
        aux.append("Total de Turmas: ").append(Total_Turmas).append("\n");
        aux.append("Turmas Alocadas: ").append(Turmas_Alocadas).append("\n");
        aux.append("Espaços Livres: ").append(espaco_livre_total).append("\n");

        return aux.toString();
    }
    public String relatorioTurmasPorSala(){
        StringBuilder aux=new StringBuilder();
        aux.append("Total de Salas: ").append(Total_Salas).append("\n");
        aux.append("Total de Turmas: ").append(Total_Turmas).append("\n");
        aux.append("Turmas Alocadas: ").append(Turmas_Alocadas).append("\n");
        aux.append("Espaços Livres: ").append(espaco_livre_total).append("\n");
        for(Sala sala:salas){
            aux.append("--- ").append(sala.getDescricao()).append(" ---").append("\n");
            for(TurmaEmSala turma_sala:ensalamento){
                if(sala.equals(turma_sala.sala)){
                    aux.append(turma_sala.turma.getDescricao());
                    
                }
            }
        }

        return aux.toString();
    }
    public String relatorioSalasPorTurma(){
        StringBuilder aux=new StringBuilder();
        aux.append("Total de Salas: ").append(Total_Salas).append("\n");
        aux.append("Total de Turmas: ").append(Total_Turmas).append("\n");
        aux.append("Turmas Alocadas: ").append(Turmas_Alocadas).append("\n");
        StringBuilder espaco_livre_aux=new StringBuilder();
        
        aux.append("Espaços Livres: ");
        int control=0;

        StringBuilder aux2=new StringBuilder();
        for(Turma aux_turma:turmas){
            System.out.printf("aqu");
            aux2.append("\n").append(aux_turma.getDescricao());
            for(TurmaEmSala turmas_sala:ensalamento){
                if(aux_turma.equals(turmas_sala.turma)){
                    espaco_livre_aux.append(turmas_sala.sala.capacidade-turmas_sala.turma.numAlunos);
                    aux2.append("\n");
                    aux2.append("Sala: ").append(turmas_sala.sala.getDescricao());
                    control++;
                }
            
            }
        }
        StringBuilder aux3=new StringBuilder();
        aux.append("");
        if(control==0){
            espaco_livre_aux.append("0");
            aux3.append("\nSala: SEM SALA");
        }
       
        
        if(control>1){
            return aux.toString()+espaco_livre_aux+aux2.toString()+espaco_livre_aux.toString();
        }
        return aux.toString()+espaco_livre_aux+aux2.toString()+aux3.toString();
    }
    public static void main(String[] args) {
        Ensalamento aox= new Ensalamento();
        final Sala aox2=new Sala(25, 102, 52, false);
        Turma aui=new Turma("25", "455", 58, false);
        aox.addSala(aox2);
        aox.addTurma(null);
        System.out.println(aox.relatorioSalasPorTurma());
        
    }
}
