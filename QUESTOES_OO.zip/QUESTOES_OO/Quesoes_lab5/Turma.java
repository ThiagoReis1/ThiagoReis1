import java.util.ArrayList;

import java.util.HashMap;
import java.util.Map;

public class Turma {
    String nome; 
    String professor; 
    int numAlunos;
    boolean acessivel;
    ArrayList<Integer> horarios= new ArrayList<Integer>();
    Turma(){}
    Turma(String nome, String professor, int numAlunos, boolean acessivel){
        this.nome=nome;
        this.professor=professor;
        this.numAlunos=numAlunos;
        this.acessivel=acessivel;
    }
    public void  addHorario(int horario){
        horarios.add(horario);
    }
    public String getHorariosString(){

        /*
            Hs/Dia	Seg	Ter	Qua	Qui	Sex
            8	    1	8	15	22	29
            10	    2	9	16	23	30
            12	    3	10	17	24	31
            14	    4	11	18	25	32
            16	    5	12	19	26	33
            18	    6	13	20	27	34
            20	    7	14	21	28	35
         */
        Map<Integer, String> horarios = new HashMap<>();

        horarios.put(1, "segunda 8hs");
        horarios.put(8, "terça 8hs");
        horarios.put(15, "quarta 8hs");
        horarios.put(22, "quinta 8hs");
        horarios.put(29, "sexta 8hs");

        horarios.put(2, "segunda 10hs");
        horarios.put(9, "terça 10hs");
        horarios.put(16, "quarta 410hs");
        horarios.put(23, "quinta 10hs");
        horarios.put(30, "sexta 10hs");

        horarios.put(3, "segunda 12hs");
        horarios.put(10, "terça 12hs");
        horarios.put(17, "quarta 12hs");
        horarios.put(24, "quinta 12hs");
        horarios.put(31, "sexta 12hs");
        
        horarios.put(4, "segunda 14hs");
        horarios.put(11, "terça 14hs");
        horarios.put(18, "quarta 14hs");
        horarios.put(25, "quinta 14hs");
        horarios.put(32, "sexta 14hs");            

        horarios.put(5, "segunda 16hs");
        horarios.put(12, "terça 16hs");
        horarios.put(19, "quarta 16hs");
        horarios.put(26, "quinta 16hs");
        horarios.put(33, "sexta 16hs");

        horarios.put(6, "segunda 18hs");
        horarios.put(13, "terça 18hs");
        horarios.put(20, "quarta 18hs");
        horarios.put(27, "quinta 18hs");
        horarios.put(34, "sexta 18hs");
        
        horarios.put(7, "segunda 20hs");
        horarios.put(14, "terça 20hs");
        horarios.put(21, "quarta 20hs");
        horarios.put(28, "quinta 20hs");
        horarios.put(35, "sexta 20hs");

        StringBuilder aux=new StringBuilder();
        int control=0;

        for(int num:this.horarios){
            if(control!=0){
                aux.append(", ");
            }
            aux.append(horarios.get(num));
            control++;
        }
        return aux.toString();
    }
    public String	getDescricao(){
        StringBuilder aux= new StringBuilder();

/*
 Turma: Sistemas Operacionais
Professor: Andrew S. Tanenbaum
Número de Alunos: 65
Horário: segunda 16hs, quarta 16hs, sexta 16hs
Acessível: sim
 */
        aux.append("Turma: ").append(this.nome);
        aux.append("\nProfessor: ").append(this.professor);
        aux.append("\nNúmero de Alunos: ").append(this.numAlunos);
        aux.append("\nHorário: ").append(getHorariosString());
        aux.append("\nAcessível: ").append(this.acessivel ? "sim":"não");
        
        return aux.toString();
    }

    /*
     public static void main(String[] args) {
        Turma Myturma= new Turma("A", "null", 60, false);
        Myturma.addHorario(10);
        Myturma.addHorario(20);
        Myturma.addHorario(50);

        System.out.println( Myturma.getHorariosString());
       
    }    
     
     */

}
