public class Sala {

	int bloco;
    int	sala;
    int capacidade;
    boolean acessivel;
    Sala(){}
    Sala(int bloco, int sala, int capacidade, boolean acessivel){
        this.bloco=bloco;
        this.sala=sala;
        this.capacidade=capacidade;
        this.acessivel=acessivel;
    }
    public String getDescricao(){
        StringBuilder temp=new StringBuilder();
        String aux="acessível";
        if(acessivel==false){
            aux="não acessível";
        }
        temp.append("Bloco ").append(this.bloco).append(", Sala ").append(this.sala).append(" (")
        .append(capacidade).append(" lugares, ").append(aux).append(")");
        return temp.toString();
    }

}