import java.util.ArrayList;

public class Ensalamento1 {
	ArrayList<Sala> salas=new ArrayList<Sala>();;
    ArrayList<Turma> turmas= new ArrayList<Turma>();
    ArrayList<TurmaEmSala> ensalamento= new ArrayList<TurmaEmSala>();



    Ensalamento1(){}
    public void addSala(Sala sala){
        salas.add(sala);
    }
    public void addTurma(Turma turma){
        turmas.add(turma);
    }
    public Sala getSala(Turma turma){
        for(Sala sala:salas){
            
        }
    }
    public boolean salaDisponivel(Sala sala, int horario){
        

        return false;
    }
    public boolean	salaDisponivel(Sala sala, ArrayList<Integer> horarios){

    }
    public boolean	alocar(Turma turma, Sala sala){

        if((turma.acessivel && sala.acessivel) && (turma.numAlunos<=sala.capacidade)){
            TurmaEmSala aux= new TurmaEmSala(turma, sala);
            ensalamento.add(aux);
            return true; 
        }
        return false;
    }

    public void alocarTodas(){
   
        for(Turma turma:this.turmas){
            
        }
    }
    
    public int	getTotalTurmasAlocadas(){

    }
    public int getTotalEspacoLivre(){

    }
    public String	relatorioResumoEnsalamento(){

    }
    public String relatorioTurmasPorSala(){

    }
    public String relatorioSalasPorTurma(){

    } 
}
