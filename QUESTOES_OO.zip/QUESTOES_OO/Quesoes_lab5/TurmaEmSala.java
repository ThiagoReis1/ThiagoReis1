public class TurmaEmSala {
	Turma turma; 
    Sala sala; 
    TurmaEmSala(){}
    TurmaEmSala(Turma turma, Sala sala){
        this.turma=turma;
        this.sala=sala;
    }

      
}
