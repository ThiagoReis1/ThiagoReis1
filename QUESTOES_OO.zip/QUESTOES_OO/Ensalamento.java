import java.util.ArrayList;


public class Ensalamento{

    ArrayList<Sala> salas = new ArrayList<Sala> (); 
    ArrayList<Turma> turmas= new ArrayList<Turma>();
    ArrayList<TurmaEmSala> ensalamento = new ArrayList<TurmaEmSala>();

    


    public Ensalamento(){

    }

    public void addSala(Sala sala){
        this.salas.add(sala);
    }

    public void addTurma(Turma turma){
        this.turmas.add(turma);
    }

    public Sala	getSala(Turma turma){
        for(TurmaEmSala aux: ensalamento){
            if(aux.turma.equals(turma)){
                return aux.sala;
            }
        }
        return null;

    }


    public boolean	salaDisponivel(Sala sala, int horario){

        for(TurmaEmSala aux:ensalamento){
            if(aux.sala.equals(sala)){
                if(aux.turma.horarios.contains(horario)){
                    return false;
                }
                
            }
        }
        return true;
    }
    public boolean	salaDisponivel(Sala sala, ArrayList<Integer> horarios){

        if( sala.acessivel==false){
            return false;
        }

        for(TurmaEmSala aux:ensalamento){
            if(aux.sala.equals(sala)){
                for(int num:horarios){
                    if(aux.turma.horarios.contains(num)){
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public boolean	alocar(Turma turma, Sala sala){
        if(sala.acessivel==true && turma.acessivel==true){
            if(salaDisponivel(sala, turma.horarios)){
                if(sala.capacidade>=turma.numAlunos){
                    TurmaEmSala auxiliar= new TurmaEmSala(turma,sala);
                    this.ensalamento.add(auxiliar);
                    
                    
                    return true;
                }
            }
        }
        return false;
    }
        
    //********************* */
    public void alocarTodas(){
        int i=0;

        
        for(Turma turma:turmas){
            if(i<salas.size()){
                alocar(turma, salas.get(i));
                    
                    i++;
                }
          
            }  
        }
    


    //****************** *
    public int	getTotalTurmasAlocadas(){

        return this.ensalamento.size();
    }
    public int	getTotalEspacoLivre(){
        int espaco_livre=0;
        for(TurmaEmSala aux:ensalamento){
            espaco_livre+=aux.sala.capacidade-aux.turma.numAlunos;
        }
        return espaco_livre;
    }
    public String	relatorioResumoEnsalamento(){
        StringBuilder aux= new StringBuilder();
/*
Total de Salas: 1
Total de Turmas: 1
Turmas Alocadas: 0
Espaços Livres: 0
 */
        aux.append("Total de Salas: ").append(this.salas.size()).append("\n");
        aux.append("Total de Turmas: ").append(this.turmas.size()).append("\n");
        aux.append("Turmas Alocadas: ").append(this.ensalamento.size()).append("\n");
        aux.append("Espaços Livres: ").append(getTotalEspacoLivre()).append("\n");

        return aux.toString();
    }
    public String	relatorioTurmasPorSala(){
        StringBuilder aux= new StringBuilder();
        aux.append("\n");

        for(Sala sala:this.salas){
            aux.append("--- ").append(sala.getDescricao()).append(" ---");
            for(TurmaEmSala auxiliar:ensalamento){
                if(auxiliar.sala.equals(sala)){
                    aux.append(auxiliar.turma.getDescricao());
                }
            }
        }

        return relatorioResumoEnsalamento() + aux;
    }


    public String	relatorioSalasPorTurma(){
        StringBuilder aux= new StringBuilder();
        aux.append("\n");

        int control=0;
        for(Turma turma:this.turmas){
            aux.append(turma.getDescricao());
            for(TurmaEmSala auxiliar:ensalamento){
                if(auxiliar.turma.equals(turma)){
                    aux.append("Sala: ").append(auxiliar.sala.getDescricao());
                    control=1;
                }
                else{
                    control=0;
                }
                
                
            }
            if(control==0){
                aux.append("Sala: SEM SALA");
                control=1;
            }

        }
        


        return relatorioResumoEnsalamento() + aux;
    }


}