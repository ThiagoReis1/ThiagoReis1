public class VarargsVetor {

    public static int somaVetor(int vetor[]){
        int total=0;
        for(int valor:vetor){
            total+=valor;
        }
        return total;
    }
    /* 
    public static int somaVetor(Integer... vetor){
        int total=0;
        for(int valor:vetor){
            total+=valor;
        }
        return total;
    }
    */
    public static int somaVetor(int mult,Integer... vetor){
        int total=0;
        for(int valor:vetor){
            total+=valor;
        }
        return total*mult;
    }
    public static void main(String[] args) {
        int vetor[]={1,2,3};
        System.out.println(somaVetor(vetor));
        System.out.println(somaVetor(10,20,30));
        System.out.println(somaVetor(2,10,20,30));
    }
}
