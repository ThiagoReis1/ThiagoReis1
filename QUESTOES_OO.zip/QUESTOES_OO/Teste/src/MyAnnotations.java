@interface MyAnnotations {

    String autor();
    int AulaNumero();

    String blog() default "https://google.com";

    
}
