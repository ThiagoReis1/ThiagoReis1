
@MyAnnotations(
    autor = "Thiago", AulaNumero = 65 ,blog = "google.com"
)
    
public class MainAnnotations{

    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        final int MB= 1024 *1024;
        double memoria_usada = (runtime.totalMemory() - runtime.freeMemory())/MB;
        System.out.println("Memoria usada atualmente pela JVM :  "+memoria_usada+" MB");
        System.out.println("Memoria disponivel para a JVM :  "+(runtime.totalMemory())/MB+" MB");
    }
}