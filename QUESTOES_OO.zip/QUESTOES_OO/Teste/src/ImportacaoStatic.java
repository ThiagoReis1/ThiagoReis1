import static java.lang.Math.*;

public class ImportacaoStatic{


    public static double potencia(int valor,int quant){
        return(pow(valor, quant));
    }

    public static double raizQuadrada(int valor){
        return sqrt(valor);
    }
    public static void main(String[] args) {
        System.out.println(potencia(2, 3));
        System.out.println(sqrt(100));
    }
}