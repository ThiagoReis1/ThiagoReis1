public class MainEnum {
    public static void main(String[] args) {
        System.out.println(MyEnum.DOMINGO);
        System.out.println(MyEnum.DOMINGO.name());
        System.out.println(MyEnum.DOMINGO.ordinal());

        // extende da classe Enum automaticamente
    }
}
