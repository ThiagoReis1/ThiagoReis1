public class Formulario {
    enum classe{
        MAGO(1),MONGE(2);

        private int valor;
        classe(int valor){
            this.valor=valor;
        }
    }
}