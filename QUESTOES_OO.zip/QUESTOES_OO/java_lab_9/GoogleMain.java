public class GoogleMain {
    public static void main(String[] args) {
        ListaInvertida aux= new ListaInvertida();
        aux.insere("akka", "document1.txt");
        aux.busca("akka");
        aux.toString();
    }
}
