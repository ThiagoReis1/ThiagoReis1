import java.util.Hashtable;
import java.util.LinkedList;

public class ListaInvertida {
    private Hashtable<String, LinkedList<String>> tabela;

    public ListaInvertida() {
        tabela = new Hashtable<String, LinkedList<String>>();
    }

    public boolean insere(String palavra, String documento) {
        LinkedList<String> documentos = tabela.get(palavra);

        if (documentos != null) {
            if (!documentos.contains(documento)) {
                documentos.add(documento);
                return true;
            } else {
                return false;
            }
        } else {
            LinkedList<String> novaLista = new LinkedList<String>();
            novaLista.add(documento);
            tabela.put(palavra, novaLista);
            return true;
        }
    }

    public LinkedList<String> busca(String palavra) {
        return tabela.get(palavra);
    }

    @Override
    public String toString() {
        return tabela.toString();
    }
}