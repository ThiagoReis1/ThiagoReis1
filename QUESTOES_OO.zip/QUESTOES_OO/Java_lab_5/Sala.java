public class Sala {
    int bloco;
    int sala;
    int capacidade;
    boolean acessivel;
    private String acessivelS; 
    Sala(){}
    Sala(int bloco, int sala, int capacidade, boolean acessivel){
        this.bloco=bloco;
        this.sala=sala;
        this.capacidade=capacidade;
        this.acessivel=acessivel;
        if(acessivel==true){
            this.acessivelS="acessível)";
        }
        else{
            this.acessivelS="não acessível)";
        }
    }
    public String getDescricao(){
        StringBuilder aux = new StringBuilder();

        // Bloco 6, Sala 101 (50 lugares, acessível)
        aux.append("Bloco ").append(this.bloco).append(", Sala ").append(this.sala).append(" (").append(this.capacidade).append(" lugares, ").append(acessivelS);

        return aux.toString();
    }
/*

    public static void main(String[] args) {
        Sala aux = new Sala(6,101,50,true);
        System.out.println(aux.getDescricao());
    }
 */
}
