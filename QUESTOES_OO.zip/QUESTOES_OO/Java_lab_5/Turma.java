import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Turma {

    String nome;
    String professor;
    int numAlunos;
    boolean acessivel;
    ArrayList<Integer> horarios = new ArrayList<Integer>();

    private Map<Integer, String> DicHorarios = new HashMap<>();

    Turma(){}
    Turma(String nome, String professor, int numAlunos, boolean acessivel){
        this.nome=nome;
        this.professor=professor;
        this.numAlunos=numAlunos;
        this.acessivel=acessivel;
    }

    public void addHorario(int horario){
        
/*

Hs/Dia	Seg	Ter	Qua	Qui	Sex
8	1	8	15	22	29
10	2	9	16	23	30
12	3	10	17	24	31
14	4	11	18	25	32
16	5	12	19	26	33
18	6	13	20	27	34
20	7	14	21	28	35

*/
        DicHorarios.put(1, "segunda 8hs");
        DicHorarios.put(2, "segunda 10hs");
        DicHorarios.put(3, "segunda 12hs");
        DicHorarios.put(4, "segunda 14hs");
        DicHorarios.put(5, "segunda 16hs");
        DicHorarios.put(6, "segunda 18hs");
        DicHorarios.put(7, "segunda 20hs");

        DicHorarios.put(8, "terça 8hs");
        DicHorarios.put(9, "terça 10hs");
        DicHorarios.put(10, "terça 12hs");
        DicHorarios.put(11, "terça 14hs");
        DicHorarios.put(12, "terça 16hs");
        DicHorarios.put(13, "terça 18hs");
        DicHorarios.put(14, "terça 20hs");

        DicHorarios.put(15, "quarta 8hs");
        DicHorarios.put(16, "quarta 10hs");
        DicHorarios.put(17, "quarta 12hs");
        DicHorarios.put(18, "quarta 14hs");
        DicHorarios.put(19, "quarta 16hs");
        DicHorarios.put(20, "quarta 18hs");
        DicHorarios.put(21, "quarta 20hs");

        DicHorarios.put(22, "quinta 8hs");
        DicHorarios.put(23, "quinta 10hs");
        DicHorarios.put(24, "quinta 12hs");
        DicHorarios.put(25, "quinta 14hs");
        DicHorarios.put(26, "quinta 16hs");
        DicHorarios.put(27, "quinta 18hs");
        DicHorarios.put(28, "quinta 20hs");

        DicHorarios.put(29, "sexta 8hs");
        DicHorarios.put(30, "sexta 10hs");
        DicHorarios.put(31, "sexta 12hs");
        DicHorarios.put(32, "sexta 14hs");
        DicHorarios.put(33, "sexta 16hs");
        DicHorarios.put(34, "sexta 18hs");
        DicHorarios.put(35, "sexta 20hs");







        horarios.add(horario);
    }

    public String getHorariosString(){

    StringBuilder aux = new StringBuilder();
    for(int i=0;i<this.horarios.size();i++){

        aux.append(DicHorarios.get(this.horarios.get(i)));
        if(i<this.horarios.size()-1){
            aux.append(", ");
        }
    }
    return aux.toString();

    }

    public String getDescricao(){

    StringBuilder aux = new StringBuilder();
/*
Turma: Algoritmos e Estrutura de Dados I
Professor: Edleno Silva
Número de Alunos: 60
Horário: segunda 8hs, quarta 8hs, sexta 8hs
Acessível: sim
 */
    aux.append("Turma: ").append(this.nome).append("\n");
    aux.append("Professor: ").append(this.professor).append("\n");
    aux.append("Número de Alunos: ").append(this.numAlunos).append("\n");
    aux.append("Horário: ").append(getHorariosString()).append("\n");
    aux.append("Acessível: ").append( this.acessivel ? "sim":"não").append("\n");

    return aux.toString(); 
    }
}
