public class Processador{
    
        String marca;
        String modelo;
        double velocidade;
        int numNucleos;
    Processador(){}
    Processador(String marca, String modelo, double velocidade, int numNucleos){
        this.marca=marca;
        this.modelo=modelo;
        this.velocidade=velocidade;
        this.numNucleos=numNucleos;
    }
    public double getVelocidadeParalela(){
        return this.velocidade*this.numNucleos;
    }
    public String getDescricao(){
        return String.format("Processador: marca=%s, modelo=%s, velocidade=%.1fGHz, numNucleos=%d, velocidadeParalela=%.1fGHz.",marca,modelo,velocidade,numNucleos,(velocidade*numNucleos));
        
    }


}