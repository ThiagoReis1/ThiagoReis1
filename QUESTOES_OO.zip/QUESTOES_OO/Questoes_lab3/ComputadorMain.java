public class ComputadorMain {
    public static void main(String[] args) {
        Processador P=new Processador();
        Memoria M=new Memoria();
        Disco D= new Disco();
        Computador C=new Computador();
    }
}
