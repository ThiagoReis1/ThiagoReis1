public class Memoria{
        
    String marca;
    String tipo;
    double tamanho;
    double velocidade;
    int	numPentes;

    Memoria(){}
    Memoria(String marca, String tipo, double tamanho, double velocidade, int numPentes){
        this.marca=marca;
        this.tipo=tipo;
        this.velocidade=velocidade;
        this.tamanho=tamanho;
        this.numPentes=numPentes;
    }
    public double 	getTamanhoTotal(){
        return this.tamanho*this.numPentes;
    }
    public double getVelocidadeParalela(){
        return this.numPentes*this.velocidade;
    }
    public String getDescricao(){
        return String.format("Memoria: marca=%s, tipo=%s, tamanho=%.1fGB, velocidade=%.1fGHz, numPentes=%d, tamanhoTotal=%.1fGB, velocidadeParalela=%.1fGHz.",marca,tipo,tamanho,velocidade,numPentes,tamanho*numPentes,numPentes*velocidade);
        
    }


}