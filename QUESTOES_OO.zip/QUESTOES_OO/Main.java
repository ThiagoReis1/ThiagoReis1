import java.util.ArrayList;

import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;


public class Main {
    
    
    public static void main(String[] args) throws IOException{
        Scanner teclado= new Scanner(System.in);


        

        

        File myObj = new File("Dados.txt");

        Scanner myReader = new Scanner(myObj);

  
        ArrayList<String> auxiliar = new ArrayList<String>();

        while (myReader.hasNextLine()) {
            String data []= myReader.nextLine().split(": ");
            auxiliar.add(data[0].toString()+": ");
            auxiliar.add(Integer.toString(Integer.parseInt(data[1])+100));
            auxiliar.add("\n");

          }


      

        OutputStream os = new FileOutputStream("Dados.txt"); // nome do arquivo que será escrito
        Writer wr = new OutputStreamWriter(os); // criação de um escritor
        BufferedWriter saida = new BufferedWriter(wr); // adiciono a um escritor de buffer

        int i=0;
        for(String aux:auxiliar) {
            
            if(!aux.equals(" ")){
                saida.write(aux);
            }
            
            
            if(i%2==1 && !aux.equals(" ")){
                saida.newLine();
            }
            
            //System.out.print(aux+"->\n ");

          }
          saida.close();
          
                  
          CloseScreen.clear();

      
    }
    

}
