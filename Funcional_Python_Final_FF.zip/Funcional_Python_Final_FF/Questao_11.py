

"""
Defina a função todos_imparesQ que recebe como argumento uma lista de números inteiros w e
devolve True se w contém apenas números ímpares e False em caso contrário.
Exemplo: todos_imparesQ([3,5,7,9,11]) = True
todos_imparesQ([3,4,7,9,11]) = False

"""

from functools import reduce

def todos_imparesQ(w):
    if not w:
        return True
    else:
        if w[0] % 2 == 0:
            return False
        else:
            return todos_imparesQ(w[1:])




print(todos_imparesQ([3, 5, 7, 9, 11]))  # True
print(todos_imparesQ([3, 4, 7, 9, 11]))  # False
