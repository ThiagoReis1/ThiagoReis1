from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função permutacao que recebe como argumentos duas listas w1 e w2 e devolve True se
w2 for permutação de w1, e devolve False em caso contrário.
Exemplo: permutacao([1,2,3],[3,2,1]) = True
permutacao([1,1,2,3],[3,2,1]) = False
"""

def permutacao(w1, w2):
    if len(w1) != len(w2):
        return False
    if len(w1) == 0:
        return True
    if w1[0] in w2:
        w2.remove(w1[0])
        return permutacao(w1[1:], w2)
    else:
        return False


print(permutacao([1,2,3],[3,2,1]))  # True
