

"""
Defina a função escolhe_pares que recebe como argumento uma lista de números inteiros w e
devolve a lista dos elementos pares de w.
Exemplo: escolhe_pares([1,2,3,4,5,6,7,8]) = [2, 4, 6, 8]

"""
from functools import reduce

def escolhe_pares(w):
    return list(filter(lambda x: x % 2 == 0, w))


print(escolhe_pares([1, 2, 3, 4, 5, 6, 7, 8]))  # [2, 4, 6, 8]
