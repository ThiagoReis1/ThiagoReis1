

"""
Defina a função conta que recebe como argumentos uma lista de números inteiros w e um
número inteiro x e devolve o número de ocorrências de x em w.
Exemplo: conta([1,2,3,2,1,2],1) = 2

"""

from functools import reduce

def conta(w, x):
    if not w:
        return 0
    else:
        if w[0] == x:
            return 1 + conta(w[1:], x)
        else:
            return conta(w[1:], x)



print(conta([1,2,3,2,1,2],1))
