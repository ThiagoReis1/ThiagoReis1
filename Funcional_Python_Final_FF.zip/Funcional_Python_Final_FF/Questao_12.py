

"""
Defina a função pertenceQ que recebe como argumentos uma lista de números inteiros w e um
número inteiro n e devolve True se n ocorre em w e False em caso contrário.
Exemplo: pertenceQ([1,2,3,4],5) = False
pertenceQ([1,2,3,4],5) = True
"""

from functools import reduce

def pertenceQ(w, n):
    if not w:
        return False
    else:
        if w[0] == n:
            return True
        else:
            return pertenceQ(w[1:], n)





print(pertenceQ([1, 2, 3, 4], 5))  # False
print(pertenceQ([1, 2, 3, 4], 3))  # True
