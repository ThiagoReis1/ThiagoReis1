

"""
Defina a função div que recebe como argumentos dois números naturais m e n e devolve o
resultado da divisão inteira de m por n. Neste exercício não pode recorrer às operações
aritméticas de multiplicação, divisão e resto da divisão inteira.
Exemplo: div(7,2) = 3

"""
from functools import reduce

def div(m, n):
    if m < n:
        return 0
    return 1 + div(m - n, n)


print(div(7, 2))  # 3


