from functools import reduce

"""

Defina a função pos_max que recebe como argumento uma lista de números inteiro e devolve a
lista das posições onde ocorre o máximo da lista.
Exemplo: pos_max([1,2,3,1,2,3]) = [2, 5]

"""

def pos_max(lst, max_val=None, curr_pos=0, max_pos=[]):
    if not lst:
        return max_pos
    elif max_val is None or lst[0] > max_val:
        return pos_max(lst[1:], lst[0], curr_pos + 1, [curr_pos])
    elif lst[0] == max_val:
        return pos_max(lst[1:], max_val, curr_pos + 1, max_pos + [curr_pos])
    else:
        return pos_max(lst[1:], max_val, curr_pos + 1, max_pos)

 
print(pos_max([1, 2, 3, 1, 2, 3]))  # [2, 5]
