from functools import reduce

"""
Defina a função lposicoes que recebe como argumentos uma lista de números inteiros w e um
número inteiro k e devolve a lista das posições em que k ocorre em w.
Exemplo: lposicoes([1,2,3,4,12,2,4,3,2],2) = [1, 5, 8]
"""
def lposicoes(w, k, index=0):
    if not w:
        return []
    elif w[0] == k:
        return [index] + lposicoes(w[1:], k, index + 1)
    else:
        return lposicoes(w[1:], k, index + 1)


print(lposicoes([1, 2, 3, 4, 12, 2, 4, 3, 2], 2))  # [1, 5, 8]
