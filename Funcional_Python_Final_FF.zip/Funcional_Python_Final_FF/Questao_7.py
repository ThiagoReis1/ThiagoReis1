

"""
Defina a função triangulo que recebe como argumento um número natural n e devolve uma lista
em que o primeiro elemento é a lista [1], o segundo elemento é a lista [1, 2] e assim
sucessivamente até n.
Exemplo: triangulo(4) = [[1], [1, 2], [1, 2, 3], [1, 2, 3, 4]]

"""
from functools import reduce

def triangulo(n):
    if n == 0:
        return []
    else:
        tri_linha = list(range(1, n+1))
        return triangulo(n-1) + [tri_linha]



print(triangulo(4))
