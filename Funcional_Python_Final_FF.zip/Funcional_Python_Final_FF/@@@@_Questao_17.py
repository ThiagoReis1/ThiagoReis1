

"""
Defina a função int_matrizQ que recebe como argumento uma lista m e devolve True se m for
uma matriz de números inteiros e False em caso contrário.
Exemplo: int_matrizQ([[1,2],[4,5],[7,8]]) = True
int_matrizQ([[1,2],[4],[7,8]]) = False
int_matrizQ([[1,2],[4],7]) = False
"""
from functools import reduce

def int_matrizQ(m):
    if isinstance(m, list) and len(m) > 0:
        return all(map(int_listaQ, m))
    return False

def int_listaQ(w):
    return all(map(lambda x: isinstance(x, int), w))

matriz1 = [[1, 2], [4, 5], [7, 8]]
resultado1 = int_matrizQ(matriz1)
print(resultado1)  # True

matriz2 = [[1, 2], [4], [7, 8]]
resultado2 = int_matrizQ(matriz2)
print(resultado2)  # False

matriz3 = [[1, 2], [4], 7]
resultado3 = int_matrizQ(matriz3)
print(resultado3)  # False
