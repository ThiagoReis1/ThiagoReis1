from functools import reduce

"""
Defina a função prod_lista que recebe como argumento uma lista de números inteiros e devolve
o produto dos seus elementos.
Exemplo: prod_lista([2,4,6]) = 48
prod_lista([]) = 1

"""



def prod_lista(lista):
    if not lista:
        return 1
    else:
        return lista[0] * prod_lista(lista[1:])


print(prod_lista([2, 4, 6]))
