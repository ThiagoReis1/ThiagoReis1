from functools import reduce

"""
Defina a função media_digitos que recebe como argumento um número natural e devolve a
média dos seus dígitos.
Exemplo: media_digitos(14276) = 4.0
"""

def media_digitos(n):
    if n < 10:
        return n
    soma = n % 10 + media_digitos(n // 10)
    qtd_digitos = contar_digitos(n)
    return soma / qtd_digitos

def contar_digitos(n):
    if n < 10:
        return 1
    return 1 + contar_digitos(n // 10)


print(media_digitos(14276))  # 4.0
