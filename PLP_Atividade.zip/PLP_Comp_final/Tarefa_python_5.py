

def main():
    


    #meuArquivo = pandas.read_excel("alunos_IFPB.xlsx")
    arquivo= open("alunos_IFPB.csv","r",encoding='UTF8')

    texto:list[str] = arquivo.readlines()
    tamanho=len(texto)
    DIC={}
    DIC={}
    
    for x in range(0,tamanho):
     
        Str_separada:list[str]=texto[x].split(",")
        primeiro_nome_separado=Str_separada[0].split(" ")
     
        #if(" DA","DE","DO" in texto[x]  ):
        #print(primeiro_nome_separado)
       
    
        #print("\ncodigo curso: "+ Str_separada[2] +"\n")
        if(Str_separada[5] not in DIC.keys()):
            DIC[Str_separada[5]] = 1
        else:
            DIC[Str_separada[5]]+=1 

        

    
    for x in DIC.keys():
        print(x,end=": ")
        print(DIC[x])                

        print("\n")

main()



