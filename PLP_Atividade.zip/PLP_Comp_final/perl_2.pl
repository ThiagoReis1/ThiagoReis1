use strict;
use warnings;

sub main {
    my $arquivo = 'alunos_IFPB.csv';
    open(my $fh, '<', $arquivo) or die "Não foi possível abrir o arquivo: $!";
    
    
    my $cabecalho = <$fh>;  # Ignorar o cabeçalho
    my $da=" DA ";
    my $de=" DE ";
    my $do=" DO ";
    
    while (my $linha = <$fh>) {
        #print "$linha\n";
        my $aux1 = "Thiago";
        my $aux2 = "Miguel";
        my @spl = split(',', $linha);
        #print "@spl[0]\n";
        

        if ((index(lc @spl[0], lc $da) != -1) || (index(lc @spl[0], lc $de) != -1) || (index(lc @spl[0], lc $do) != -1)){
            print "@spl[0]\n";
            print "@spl[1]\n\n";
        } 
    }
    
    close($fh);
}

main();
