use strict;
use warnings;

sub main {
    my $arquivo = 'alunos_IFPB.csv';
    open(my $fh, '<', $arquivo) or die "Não foi possível abrir o arquivo: $!";
    
    
    my $cabecalho = <$fh>;  # Ignorar o cabeçalho
    my $joao_pessoa="JOÃO PESSOA";

    
    while (my $linha = <$fh>) {


        my @spl = split(',', $linha);

        

        if ((index(lc $spl[4], lc $joao_pessoa) != -1)){
            print "$spl[1]\n";

        } 
    }
    
    close($fh);
}

main();
