use strict;
use warnings;

sub main {
    my $arquivo = 'alunos_IFPB.csv';
    open(my $fh, '<', $arquivo) or die "Não foi possível abrir o arquivo: $!";
    
    
    #my $cabecalho = <$fh>;  # Ignorar o cabeçalho
    my %langs = ();
    
    
    while (my $linha = <$fh>) {
        my @spl = split(',', $linha);
        
        my @names = keys %langs; # Vai guarda todas as chaves em uma lista
        


        if (exists($langs{$spl[5]})) {
            #print "@spl[3]\n";
            $langs{$spl[5]} += 1;
        }
        else{
            $langs{$spl[5]} = 1 ;
        }
    }
for(keys %langs){
	print("$_: $langs{$_}\n");

}
    

    #print "\ncurso: @names[45]";
    close($fh);
}

main();
