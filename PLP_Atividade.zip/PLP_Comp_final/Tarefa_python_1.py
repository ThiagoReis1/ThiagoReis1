#import pandas

def main():
    


    #meuArquivo = pandas.read_excel("alunos_IFPB.xlsx")
    arquivo= open("alunos_IFPB.csv","r",encoding='UTF8')
    
    texto:list[str] = arquivo.readlines()
    tamanho=len(texto)
    
    for x in range(1,tamanho):
     
        if(("Thiago "in texto[x]) or ("Miguel"in texto[x])):
            print(texto[x]) 
        

#awk -f Questao1.awk alunos_IFPB.csv

main()



