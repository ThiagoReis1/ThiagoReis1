

def main():
    


    #meuArquivo = pandas.read_excel("alunos_IFPB.xlsx")
    arquivo= open("alunos_IFPB.csv","r",encoding='UTF8')

    texto:list[str] = arquivo.readlines()
    tamanho=len(texto)
    
    for x in range(1,tamanho):
     
        Str_separada:list[str]=texto[x].split(",")
        primeiro_nome_separado=Str_separada[0].split(" ")
     
        #if(" DA","DE","DO" in texto[x]  ):
        #print(primeiro_nome_separado)
        for x in range(len(primeiro_nome_separado)):
            if("da" == primeiro_nome_separado[x] or "de"==primeiro_nome_separado[x] or "do"==primeiro_nome_separado[x]):
                print("nome: " + Str_separada[0],"\nmatricula: "+ Str_separada[1] +"\n")
                break
        



main()



