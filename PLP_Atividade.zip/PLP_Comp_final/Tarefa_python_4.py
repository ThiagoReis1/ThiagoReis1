

def main():
    


    #meuArquivo = pandas.read_excel("alunos_IFPB.xlsx")
    arquivo= open("alunos_IFPB.csv","r",encoding='UTF8')

    texto:list[str] = arquivo.readlines()
    tamanho=len(texto)
  
    
    for x in range(0,tamanho):
     
        Str_separada:list[str]=texto[x].split(",")
        primeiro_nome_separado=Str_separada[0].split(" ")

        if("JOÃO PESSOA" in Str_separada[4]):
            print(Str_separada[1])
     
        
        
       
    
        
 

main()



