#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "pilha.h"
#include "livro.h"

int main(int argc, char const *argv[]) {

  TPilha* para_ler = criar_pilha(0);

  char titulo[60];
  int anoPubl;

  scanf("%s", titulo);
  while(strcmp(titulo,"FIM")!=0){
    scanf("%d\n",&anoPubl);

    TLivro* exemplar = criar_livro(titulo, anoPubl);
    empilhar(para_ler, exemplar);

    scanf("%s", titulo);
  }
  TLivro* topo = otopo_pilha(para_ler);
  imprimir_livro(topo);

  topo = desempilhar(para_ler);
  free(topo);

  printf("altura: %d\n", altura_pilha(para_ler));

  return 0;
}
