typedef struct livro TLivro;

TLivro* criar_livro(char* titulo, int anoPubl);
void imprimir_livro(TLivro* l);
