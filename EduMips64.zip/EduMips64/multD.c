#include <stdio.h>
#define ordem 2

int main() {
    int A[] = {1, 2, 3, 4}; // Matriz A em Colunwise
    int B[] = {5, 6, 7, 8}; // Matriz B em Colunwise
    int C[] = {0, 0, 0, 0}; // Matriz C   em Colunwise
int aux=0;
    // Multiplicação das matrizes
    for (int j = 0; j < ordem; j++) {
        for (int i = 0; i < ordem; i++) {
            for (int k = 0; k < ordem; k++) {
                C[j*ordem+i] += A[k*ordem+i] * B[j*ordem+k];
                aux++;
            }
        }
    }

    // Impressão da matriz C em Colunwise
    for (int i = 0; i < ordem; i++) {
        for (int j = 0; j < ordem; j++) {
            printf("%d ", C[j*ordem+i]);
        }
    }
    printf("%d",aux);
    return 0;
}
