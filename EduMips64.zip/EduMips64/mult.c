#include <stdio.h>

int main() {
  // Declaração das matrizes A, B e C
  int A[2][2] = {{1, 3}, {2, 4}};
  int B[2][2] = {{5, 6}, {7, 8}};
  int C[2][2] = {{0, 0}, {0, 0}};

  // Realiza a multiplicação das matrizes
  for (int i = 0; i < 2; i++) {
    for (int j = 0; j < 2; j++) {
      for (int k = 0; k < 2; k++) {
        C[i][j] += A[i][k] * B[k][j];
        printf("X[%2d%2d] * Y[%2d%2d] + ", i+1,k+1 ,k+1,j+1);
      }
      printf("= %2d \n",  C[i][j]);
    }
  }

  // Imprime a matriz C resultante
  printf("Matriz resultante C:\n");
  for (int i = 0; i < 2; i++) {
    for (int j = 0; j < 2; j++) {
      printf("%d ", C[i][j]);
    }
    printf("\n");
  }

  return 0;
}