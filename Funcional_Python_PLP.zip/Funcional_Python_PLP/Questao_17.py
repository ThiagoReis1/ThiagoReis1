

"""
Defina a função int_matrizQ que recebe como argumento uma lista m e devolve True se m for
uma matriz de números inteiros e False em caso contrário.
Exemplo: int_matrizQ([[1,2],[4,5],[7,8]]) = True
int_matrizQ([[1,2],[4],[7,8]]) = False
int_matrizQ([[1,2],[4],7]) = False
"""

from functools import reduce

def int_matrizQ(matriz):
    if not isinstance(matriz, list):
        return False
    return all(isinstance(vetor, list) and all(isinstance(num, int) for num in vetor) for vetor in matriz)

print(int_matrizQ([[1,2],[4,5],[7,8]]))  
print(int_matrizQ([[1,2],[4],[7,8]]))  
print(int_matrizQ([[1,2],[4],7]))

