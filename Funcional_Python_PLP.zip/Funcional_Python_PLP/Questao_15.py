

"""
Defina a função int_lista_listaQ que recebe como argumento uma lista e devolve True se a lista
for constituída exclusivamente por listas de números inteiros e False em caso contrário.
Exemplo: int_lista_listaQ([[1,2,3],[4,5,6]]) = True
int_lista_listaQ([[1,2,3],["ola",3]]) = False
int_lista_listaQ([1,[1,2,3],[4,5,6]]) = False
"""

from functools import reduce

def int_lista_listaQ(lista):
    if not lista:
        return True
    else:
        if isinstance(lista[0], list) and all(isinstance(elem, int) for elem in lista[0]):
            return int_lista_listaQ(lista[1:])
        else:
            return False





print(int_lista_listaQ([[1, 2, 3], [4, 5, 6]]))
print(int_lista_listaQ([[1, 2, 3], ["ola", 3]]))
print(int_lista_listaQ([1, [1, 2, 3], [4, 5, 6]]))
