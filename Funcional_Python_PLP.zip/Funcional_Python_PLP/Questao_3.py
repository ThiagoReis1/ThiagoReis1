

"""
Defina a função quadrados_inv_inv que recebe como argumento um número natural n devolve a
lista dos n primeiros quadrados_inv perfeitos, por ordem decrescente.
Exemplo: quadrados_inv_inv(5) = [25, 16, 9, 4, 1]


"""


from functools import reduce

def quadrados_inv(n):
    if n == 0:
        return []
    else:
        return   [n * n] + quadrados_inv(n - 1)



print(quadrados_inv(5))