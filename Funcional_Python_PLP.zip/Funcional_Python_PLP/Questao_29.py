from functools import reduce

"""
Defina a função ind_pares que recebe como argumento uma lista de listas de números inteiros
w={w1,...,wn} e devolve a lista r={r1,...,rn} em que ri é composta pelas posições dos números
pares em wi.
Exemplo: pos_pares([[1,2,3],[4,5,6],[7,8,9,10]]) = [[1], [0, 2], [1, 3]]

"""
def ind_pares(lista):
    if not lista:
        return []
    else:
       
        return [[i for i, num in enumerate(lista[0]) if num % 2 == 0]] + ind_pares(lista[1:])


print(ind_pares([[1, 2, 3], [4, 5, 6], [7, 8, 9, 10]]))
