

"""
Defina a função intercala que recebe como argumentos duas listas w1 e w2 e devolve a lista
resultante de intercalar os elementos de w1 com os de w2.
Exemplo: intercala([1,3,5],[2,4,6]) = [1, 2, 3, 4, 5, 6]
intercala([1,3,5,7],[2]) = [1, 2, 3, 5, 7]
"""
from functools import reduce

def intercala(lista_1, lista_2):
    if lista_1 == []:
        return lista_2
    if lista_2 == []:
        return lista_1
    return [lista_1[0], lista_2[0]] + intercala(lista_1[1:], lista_2[1:])


print(intercala([1,3,5],[2,4,6]))

