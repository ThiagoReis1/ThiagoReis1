from functools import reduce
"""
Defina a função apaga que recebe como argumentos uma lista de inteiros w e um número
inteiro k e devolve a lista que resulta de apagar de w todas as ocorrências de k.
Exemplo: apaga([1,2,1,3,1,4,1,5],1) = [2, 3, 4, 5]
"""
def apaga(lista, num):
    if lista == []:
        return []
    
    if lista[0] == num:
        return apaga(lista[1:], num)
    else:
        return [lista[0]] + apaga(lista[1:], num)


print(apaga([1,2,1,3,1,4,1,5], 1))
