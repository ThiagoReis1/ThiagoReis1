from functools import reduce

"""
Defina a função lposicoes que recebe como argumentos uma lista de números inteiros w e um
número inteiro k e devolve a lista das posições em que k ocorre em w.
Exemplo: lposicoes([1,2,3,4,12,2,4,3,2],2) = [1, 5, 8]
"""


def lposicoes(lista, num, index=0):
    if not lista:
        return []
    elif lista[0] == num:
        return [index] + lposicoes(lista[1:], num, index + 1)
    else:
        return lposicoes(lista[1:], num, index + 1)


print(lposicoes([1, 2, 3, 4, 12, 2, 4, 3, 2], 2))
