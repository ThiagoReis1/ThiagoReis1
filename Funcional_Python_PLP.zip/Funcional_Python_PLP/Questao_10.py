

"""
Defina a função contem_parQ que recebe como argumento uma lista de números inteiros w e
devolve True se w contém um número par e False em caso contrário.
Exemplo: contem_parQ([3,5,7,9,11]) = False
contem_parQ([3,4,7,9,11]) = True

"""

from functools import reduce

def contem_parQ(lista):
    if not lista:
        return False
    else:
        if lista[0] % 2 == 0:
            return True
        else:
            return contem_parQ(lista[1:])





print(contem_parQ([3, 5, 7, 9, 11]))
print(contem_parQ([3, 4, 7, 9, 11]))
