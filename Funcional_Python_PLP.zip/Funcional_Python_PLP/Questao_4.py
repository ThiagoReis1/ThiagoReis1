

"""
Defina a função num_perf que recebe como argumento um número inteiro positivo e devolve
True se esse número for um número perfeito e False em caso contrário. Lembre que um número
perfeito é um número natural que é igual à soma de todos os seus divisores próprios, isto é, a
soma de todos os divisores excluindo o próprio número. Pode-se definir funções auxiliares,
desde que definidas no paradigma funcional.
Exemplo: num_perf(6) = TRUE … (1+2+3=6)
num_perf(5) = FALSE

"""
from functools import reduce

def divs_p(n):
    
    return list(filter(lambda x: n % x == 0, range(1, n)))

def num_perf(n):
    
    return reduce(lambda x, y: x + y, divs_p(n))== n



print( num_perf(5))