

"""
Defina a função indices_pares que recebe como argumento uma lista de números inteiros w e
devolve a lista dos elementos de w em posições pares.
Exemplo: indices_pares([4,3,7,1,2,9]) = [4, 7, 2]

"""
from functools import reduce

def indices_pares(lista):
    if len(lista) < 2:
        return []
    else:
        return [lista[0]] + indices_pares(lista[2:])


print(indices_pares([4, 3, 7, 1, 2, 9]))

