

"""
Defina função comprimento que recebe como argumento uma lista e devolve o seu
comprimento. Não pode, como é óbvio, recorrer à função len.
Exemplo: comprimento([2,3,5,2,2]) = 5
"""
from functools import reduce

def comprimento(lista):
    if lista == []:
        return 0
    return 1 + comprimento(lista[1:])


print(comprimento([2,3,5,2,2]))
