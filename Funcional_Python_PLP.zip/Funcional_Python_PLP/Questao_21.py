

"""
Defina a função media_digitos que recebe como argumento um número natural e devolve a
média dos seus dígitos.
Exemplo: media_digitos(14276) = 4.0
"""

from functools import reduce

def soma_vetor(lista):
    if len(lista) == 1:
        return lista[0]
    else:
        return lista[0] + soma_vetor(lista[1:])

def media_digitos(n):

    return soma_vetor(list(map(int, str(n)))) / len(list(map(int, str(n))))

print(media_digitos(14276))
