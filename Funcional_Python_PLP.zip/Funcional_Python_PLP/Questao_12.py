

"""
Defina a função pertenceQ que recebe como argumentos uma lista de números inteiros w e um
número inteiro n e devolve True se n ocorre em w e False em caso contrário.
Exemplo: pertenceQ([1,2,3,4],5) = False
pertenceQ([1,2,3,4],5) = True
"""

from functools import reduce

def pertenceQ(lista, num):
    if not lista:
        return False
    else:
        if lista[0] == num:
            return True
        else:
            return pertenceQ(lista[1:], num)





print(pertenceQ([1, 2, 3, 4], 5))
print(pertenceQ([1, 2, 3, 4], 3))
