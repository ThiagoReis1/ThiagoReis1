

"""

Defina a função inverte_lista que recebe como argumento uma lista e devolve essa lista
invertida.
Exemplo: inverteLista([1,2,3]) = [3, 2, 1]

"""
from functools import reduce

def inverte_lista(lista):
    if not lista:
        return []
    else:
        return [lista[-1]] + inverte_lista(lista[:-1])



print(inverte_lista([1,2,3]))
