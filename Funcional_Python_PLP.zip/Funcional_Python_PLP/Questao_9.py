

"""
Defina a função conta que recebe como argumentos uma lista de números inteiros w e um
número inteiro x e devolve o número de ocorrências de x em w.
Exemplo: conta([1,2,3,2,1,2],1) = 2

"""

from functools import reduce

def conta(lista, num):
    if not lista:
        return 0
    else:
        if lista[0] == num:
            return 1 + conta(lista[1:], num)
        else:
            return conta(lista[1:], num)



print(conta([1,2,3,2,1,2],1))
