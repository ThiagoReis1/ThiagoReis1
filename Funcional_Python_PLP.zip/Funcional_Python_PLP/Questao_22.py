from functools import reduce

"""

Defina a função permutacao que recebe como argumentos duas listas w1 e w2 e devolve True se
w2 for permutação de w1, e devolve False em caso contrário.
Exemplo: permutacao([1,2,3],[3,2,1]) = True
permutacao([1,1,2,3],[3,2,1]) = False
"""

def permutacao(lista_1, lista_2):
    if len(lista_1) != len(lista_2):
        return False
    if len(lista_1) == 0:
        return True
    if lista_1[0] in lista_2:
        lista_2.remove(lista_1[0])
        return permutacao(lista_1[1:], lista_2)
    else:
        return False


print(permutacao([1,2,3],[3,2,1]))
