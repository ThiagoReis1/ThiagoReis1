

"""
Defina a função prim_alg que recebe como argumento um número natural n e devolve o
primeiro algarismo (o mais significativo) na representação decimal de n.
Exemplo: prim_alg(8935) = 8
"""
from functools import reduce

def prim_alg(num):
    if num < 10:
        return num
    return prim_alg(num // 10)


print(prim_alg(8935))
