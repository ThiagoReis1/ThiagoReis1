from functools import reduce

"""
 Defina a função pos_max que recebe como argumento uma lista de números inteiro e devolve a
lista das posições onde ocorre o máximo da lista.
Exemplo: pos_max([1,2,3,1,2,3]) = [2, 5]

"""

def maximo(lista):
    if len(lista) == 1:
        return lista[0]
    else:
        if lista[0] > maximo(lista[1:]):
            return lista[0]
        else:
            return maximo(lista[1:])

def pos_max(lista):

    return list(filter(lambda i: lista[i] == maximo(lista), range(len(lista))))

print(pos_max([1, 2, 3, 1, 2, 3]))
