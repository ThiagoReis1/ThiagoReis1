

"""
Defina a função maximo que recebe como argumento uma lista não vazia de números inteiros e
devolve o seu máximo.
Exemplo: maximo([14,-1,5,19,0]) = 19

"""
from functools import reduce

def maximo(lista):
    if len(lista) == 1:
        return lista[0]
    else:
        
        if lista[0] > maximo(lista[1:]):
            return lista[0]
        else:
            return maximo(lista[1:])


print(maximo([14, -1, 5, 19, 0]))
