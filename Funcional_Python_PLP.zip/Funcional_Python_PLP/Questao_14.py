

"""
Defina a função nat_listaQ que recebe como argumento uma lista e devolve True se a lista for
constituída exclusivamente por números naturais e False em caso contrário.
Exemplo: nat_listaQ([1,2,3,-1]) = False
natt_listaQ([1,2,3,4]) = False
"""

from functools import reduce

def nat_listaQ(lista):
    if not lista:
        return True
    else:
        if isinstance(lista[0], int) and lista[0] >= 0:
            return nat_listaQ(lista[1:])
        else:
            return False






print(nat_listaQ([1, 2, 3, -1]))
print(nat_listaQ([1, 2, 3, 4]))
