from functools import reduce

# map, reduce, all, any, filter e next,

"""
Defina a função soma_nat que recebe como argumento um número natural n e devolve a soma
de todos os números naturais até n.
Exemplo: soma_nat(10) = 1+2+3+4+5+6+7+8+9+10=55
"""
def soma_nat(num:int):
    if(num==0):
        return num
    else:
        return soma_nat(num-1)+num



print(soma_nat(10))