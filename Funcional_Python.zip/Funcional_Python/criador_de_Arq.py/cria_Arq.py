# map, reduce, all, any, filter e next,


for i in range(1,31):
    aux = str("Questao_{}.py").format(i)
    arquivo = open(aux,"w")
    arquivo.write("from functools import reduce")