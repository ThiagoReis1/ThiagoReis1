from functools import reduce

# map, reduce, all, any, filter e next,

"""
Defina a função quadrados que recebe como argumento um número natural n devolve a lista
dos n primeiros quadrados perfeitos.
Exemplo: quadrados(5) = [1, 4, 9, 16, 25]
"""

def quadrados(num:int):
    if(num==0):
        return num
    else:
        return quadrados(num-1)+num

