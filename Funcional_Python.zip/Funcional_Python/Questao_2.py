from functools import reduce

# map, reduce, all, any, filter e next,

"""
Defina a função quadrados que recebe como argumento um número natural n devolve a lista
dos n primeiros quadrados perfeitos.
Exemplo: quadrados(5) = [1, 4, 9, 16, 25]
"""


from functools import reduce

from functools import reduce

def quadrados(n):
    if n == 0:
        return []
    else:
        return quadrados(n - 1) + [n * n]


resultado = quadrados(10)
print(resultado)














