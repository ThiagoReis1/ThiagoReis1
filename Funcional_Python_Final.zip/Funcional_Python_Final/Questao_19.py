from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função div que recebe como argumentos dois números naturais m e n e devolve o
resultado da divisão inteira de m por n. Neste exercício não pode recorrer às operações
aritméticas de multiplicação, divisão e resto da divisão inteira.
Exemplo: div(7,2) = 3

"""
def div(m, n):
    if m < n:
        return 0
    return 1 + div(m - n, n)

resultado = div(7, 2)
print(resultado)  # 3
