from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função conta que recebe como argumentos uma lista de números inteiros w e um
número inteiro x e devolve o número de ocorrências de x em w.
Exemplo: conta([1,2,3,2,1,2],1) = 2


"""



def conta(w, x):
    if not w:
        return 0
    else:
        if w[0] == x:
            return 1 + conta(w[1:], x)
        else:
            return conta(w[1:], x)

lista = [1, 2, 3, 2, 1, 2]
elemento = 1

print(conta(lista, elemento))
