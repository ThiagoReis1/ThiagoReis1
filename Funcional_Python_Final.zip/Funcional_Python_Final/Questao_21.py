from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função media_digitos que recebe como argumento um número natural e devolve a
média dos seus dígitos.
Exemplo: media_digitos(14276) = 4.0
"""

def media_digitos(n):
    if n < 10:
        return n
    soma = n % 10 + media_digitos(n // 10)
    qtd_digitos = contar_digitos(n)
    return soma / qtd_digitos

def contar_digitos(n):
    if n < 10:
        return 1
    return 1 + contar_digitos(n // 10)

resultado = media_digitos(14276)
print(resultado)  # 4.0
