from functools import reduce
"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função apaga que recebe como argumentos uma lista de inteiros w e um número
inteiro k e devolve a lista que resulta de apagar de w todas as ocorrências de k.
Exemplo: apaga([1,2,1,3,1,4,1,5],1) = [2, 3, 4, 5]
"""
def apaga(w, k):
    if w == []:
        return []
    if w[0] == k:
        return apaga(w[1:], k)
    return [w[0]] + apaga(w[1:], k)

resultado = apaga([1,2,1,3,1,4,1,5], 1)
print(resultado)  # [2, 3, 4, 5]
