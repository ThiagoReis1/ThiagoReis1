from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função int_lista_listaQ que recebe como argumento uma lista e devolve True se a lista
for constituída exclusivamente por listas de números inteiros e False em caso contrário.
Exemplo: int_lista_listaQ([[1,2,3],[4,5,6]]) = True
int_lista_listaQ([[1,2,3],["ola",3]]) = False
int_lista_listaQ([1,[1,2,3],[4,5,6]]) = False
"""

from functools import reduce

def int_lista_listaQ(lista):
    if not lista:
        return True
    else:
        if isinstance(lista[0], list) and all(isinstance(elem, int) for elem in lista[0]):
            return int_lista_listaQ(lista[1:])
        else:
            return False

lista1 = [[1, 2, 3], [4, 5, 6]]
lista2 = [[1, 2, 3], ["ola", 3]]
lista3 = [1, [1, 2, 3], [4, 5, 6]]

resultado1 = int_lista_listaQ(lista1)
resultado2 = int_lista_listaQ(lista2)
resultado3 = int_lista_listaQ(lista3)

print(resultado1)  # True
print(resultado2)  # False
print(resultado3)  # False
