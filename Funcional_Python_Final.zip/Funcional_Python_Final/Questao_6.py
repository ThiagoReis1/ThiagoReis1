from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função indices_pares que recebe como argumento uma lista de números inteiros w e
devolve a lista dos elementos de w em posições pares.
Exemplo: indices_pares([4,3,7,1,2,9]) = [4, 7, 2]


"""


def indices_pares(w):
    if len(w) < 2:
        return []
    else:
        return [w[0]] + indices_pares(w[2:])

lista = [4, 3, 7, 1, 2, 9]
indices_pares(lista)
print(indices_pares(lista))

