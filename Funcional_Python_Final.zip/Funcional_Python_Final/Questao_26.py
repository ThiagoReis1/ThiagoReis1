from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função maximo que recebe como argumento uma lista não vazia de números inteiros e
devolve o seu máximo.
Exemplo: maximo([14,-1,5,19,0]) = 19

"""

def maximo(lista):
    if len(lista) == 1:
        return lista[0]
    else:
        sub_max = maximo(lista[1:])
        if lista[0] > sub_max:
            return lista[0]
        else:
            return sub_max

resultado = maximo([14, -1, 5, 19, 0])
print(resultado)  # 19
