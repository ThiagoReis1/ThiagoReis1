from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função contem_parQ que recebe como argumento uma lista de números inteiros w e
devolve True se w contém um número par e False em caso contrário.
Exemplo: contem_parQ([3,5,7,9,11]) = False
contem_parQ([3,4,7,9,11]) = True

"""



def contem_parQ(w):
    if not w:
        return False
    else:
        if w[0] % 2 == 0:
            return True
        else:
            return contem_parQ(w[1:])

lista1 = [3, 5, 7, 9, 11]
lista2 = [3, 4, 7, 9, 11]




print(contem_parQ(lista1))  # False
print(contem_parQ(lista2))  # True
