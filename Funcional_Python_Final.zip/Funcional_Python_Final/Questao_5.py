from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função inverte_lista que recebe como argumento uma lista e devolve essa lista
invertida.
Exemplo: inverteLista([1,2,3]) = [3, 2, 1]


"""


def inverte_lista(lista):
    if not lista:
        return []
    else:
        return [lista[-1]] + inverte_lista(lista[:-1])

lista_original = [1, 2, 3]

print(inverte_lista(lista_original))
