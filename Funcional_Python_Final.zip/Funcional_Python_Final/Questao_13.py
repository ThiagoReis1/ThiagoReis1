from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função int_listaQ que recebe como argumento uma lista e devolve True se a lista for
constituída exclusivamente por números inteiros e False em caso contrário.
Exemplo: int_listaQ([1,2,-3,4,9]) = True
int_listaQ([1.1,3,-3]) = False

"""


def int_listaQ(lista):
    if not lista:
        return True
    else:
        if isinstance(lista[0], int):
            return int_listaQ(lista[1:])
        else:
            return False




print(int_listaQ([1, 2, -3, 4, 9]))  # True
print(int_listaQ([1.1, 3, -3]))  # False
