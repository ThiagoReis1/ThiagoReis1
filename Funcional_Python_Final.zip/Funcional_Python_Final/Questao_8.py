from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função prod_lista que recebe como argumento uma lista de números inteiros e devolve
o produto dos seus elementos.
Exemplo: prod_lista([2,4,6]) = 48
prod_lista([]) = 1

"""



def prod_lista(lista):
    if not lista:
        return 1
    else:
        return lista[0] * prod_lista(lista[1:])

lista = [2, 4, 6]

print(prod_lista(lista))
