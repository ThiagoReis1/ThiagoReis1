from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função nat_listaQ que recebe como argumento uma lista e devolve True se a lista for
constituída exclusivamente por números naturais e False em caso contrário.
Exemplo: nat_listaQ([1,2,3,-1]) = False
natt_listaQ([1,2,3,4]) = False
"""

from functools import reduce

def nat_listaQ(lista):
    if not lista:
        return True
    else:
        if isinstance(lista[0], int) and lista[0] >= 0:
            return nat_listaQ(lista[1:])
        else:
            return False

lista1 = [1, 2, 3, -1]
lista2 = [1, 2, 3, 4]

resultado1 = nat_listaQ(lista1)
resultado2 = nat_listaQ(lista2)

print(resultado1)  # False
print(resultado2)  # True
