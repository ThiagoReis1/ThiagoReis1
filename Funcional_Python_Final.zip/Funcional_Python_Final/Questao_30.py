from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função fibonacci que recebe como argumento um número natural n e devolve o
n-ésimo número da sucessão de Fibonacci. Recorde que a sucessão dos números de Fibonacci é
definida recursivamente como se segue: fibonacci(1)=1; fibonacci(2)=1; fibonacci(n+2)=
fibonacci(n+1)+ fibonacci(n)
Exemplo: fibonacci(1) = 1
fibonacci(2) = 1
fibonacci(3) = 2
"""
def fibonacci(n):
    if n == 1 or n == 2:
        return 1
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

resultado = fibonacci(5)
print(resultado)  # 5