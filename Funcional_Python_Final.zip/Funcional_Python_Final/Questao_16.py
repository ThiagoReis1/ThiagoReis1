from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função escolhe_pares que recebe como argumento uma lista de números inteiros w e
devolve a lista dos elementos pares de w.
Exemplo: escolhe_pares([1,2,3,4,5,6,7,8]) = [2, 4, 6, 8]

"""


def escolhe_pares(w):
    return list(filter(lambda x: x % 2 == 0, w))

lista = [1, 2, 3, 4, 5, 6, 7, 8]
resultado = escolhe_pares(lista)
print(resultado)  # [2, 4, 6, 8]
