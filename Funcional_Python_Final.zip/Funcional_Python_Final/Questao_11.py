from functools import reduce


"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função todos_imparesQ que recebe como argumento uma lista de números inteiros w e
devolve True se w contém apenas números ímpares e False em caso contrário.
Exemplo: todos_imparesQ([3,5,7,9,11]) = True
todos_imparesQ([3,4,7,9,11]) = False

"""

from functools import reduce

def todos_imparesQ(w):
    if not w:
        return True
    else:
        if w[0] % 2 == 0:
            return False
        else:
            return todos_imparesQ(w[1:])

lista1 = [3, 5, 7, 9, 11]
lista2 = [3, 4, 7, 9, 11]




print(todos_imparesQ(lista1))  # True
print(todos_imparesQ(lista2))  # False
