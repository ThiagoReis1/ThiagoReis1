from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função num_perf que recebe como argumento um número inteiro positivo e devolve
True se esse número for um número perfeito e False em caso contrário. Lembre que um número
perfeito é um número natural que é igual à soma de todos os seus divisores próprios, isto é, a
soma de todos os divisores excluindo o próprio número. Pode-se definir funções auxiliares,
desde que definidas no paradigma funcional.
Exemplo: num_perf(6) = TRUE … (1+2+3=6)
num_perf(5) = FALSE

"""


def divisores_proprios(n):
    divisores = filter(lambda x: n % x == 0, range(1, n))
    return list(divisores)

def num_perf(n):
    soma_divisores = reduce(lambda x, y: x + y, divisores_proprios(n))
    return soma_divisores == n



print( num_perf(5))