from functools import reduce

"""
Faça em python

Esta atividade deve utilizar recursão, mas nada de composição iterativa e composição sequencial de
comandos. As funções devem ser definidas utilizando as primitivas map, reduce, all, any, filter e next,
podendo também recorrer a outras funções sobre listas que considere necessárias (mas sempre pergunte
do professor).
Obs: Lembre que reduce precisa do import (from functools import reduce )

Defina a função retira_negativos que recebe como argumento uma lista de números inteiros e
devolve a lista resultante de retirar todos os números negativos.
Exemplo: retira_negativos([1,2,3,-4,5,-6]) = [1, 2, 3, 5]
"""
def retira_negativos(lista):
    if not lista:
        return []
    if lista[0] < 0:
        return retira_negativos(lista[1:])
    return [lista[0]] + retira_negativos(lista[1:])

lista = [1, 2, 3, -4, 5, -6]
resultado = retira_negativos(lista)
print(resultado)  # [1, 2, 3, 5]
