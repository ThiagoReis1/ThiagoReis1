package controle;

public class Cliente {
	String nome_completo;
	int sexo;
	int cpf;

}
