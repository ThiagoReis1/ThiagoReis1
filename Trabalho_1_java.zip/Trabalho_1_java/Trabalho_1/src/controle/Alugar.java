package controle;

import veiculos.Carro;

public class Alugar {
	String Data_e_local_de_retirada;
	String Data_e_local_de_devolução;
	Carro Veiculo;
	
	boolean gps; //Opcionais
	boolean seguro_completo;//Opcionais
}
