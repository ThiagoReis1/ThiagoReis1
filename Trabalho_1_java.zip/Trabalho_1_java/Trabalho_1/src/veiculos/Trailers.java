package veiculos;

public class Trailers {

}
