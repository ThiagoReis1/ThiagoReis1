package veiculos;

public class Pickups extends Carro{
	public Pickups(String categoria,int numero_maximo_de_passageiros,double volume_maximo_para_transporte,
			boolean ar_condicionado,double media_de_consumo,double potencia_do_motor,double custo_por_dia) {
		super(categoria,numero_maximo_de_passageiros,volume_maximo_para_transporte,
				ar_condicionado, media_de_consumo, potencia_do_motor,custo_por_dia);
	}
}
