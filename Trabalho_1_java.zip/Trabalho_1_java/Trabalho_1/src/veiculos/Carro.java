package veiculos;

public class Carro {
	
	
	private String categoria;
	private int numero_maximo_de_passageiros;
	private double volume_maximo_para_transporte;
	private boolean ar_condicionado;
	private double media_de_consumo; //(km/l)
	private double potencia_do_motor;
	private double custo_por_dia; //Custo_(valor)_por_dia
	public Carro(String categoria,int numero_maximo_de_passageiros,double volume_maximo_para_transporte,
			boolean ar_condicionado,double media_de_consumo,double potencia_do_motor,double custo_por_dia){
		
		this.categoria=categoria;
		this.numero_maximo_de_passageiros=numero_maximo_de_passageiros;
		this.volume_maximo_para_transporte=volume_maximo_para_transporte;
		this.ar_condicionado=ar_condicionado;
		this.media_de_consumo=media_de_consumo;
		this.potencia_do_motor=potencia_do_motor;
		this.custo_por_dia=custo_por_dia;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public int getNumero_maximo_de_passageiros() {
		return numero_maximo_de_passageiros;
	}
	public void setNumero_maximo_de_passageiros(int numero_maximo_de_passageiros) {
		this.numero_maximo_de_passageiros = numero_maximo_de_passageiros;
	}
	public double getVolume_maximo_para_transporte() {
		return volume_maximo_para_transporte;
	}
	public void setVolume_maximo_para_transporte(double volume_maximo_para_transporte) {
		this.volume_maximo_para_transporte = volume_maximo_para_transporte;
	}
	public boolean isAr_condicionado() {
		return ar_condicionado;
	}
	public void setAr_condicionado(boolean ar_condicionado) {
		this.ar_condicionado = ar_condicionado;
	}
	public double getMedia_de_consumo() {
		return media_de_consumo;
	}
	public void setMedia_de_consumo(double media_de_consumo) {
		this.media_de_consumo = media_de_consumo;
	}
	public double getPotencia_do_motor() {
		return potencia_do_motor;
	}
	public void setPotencia_do_motor(double potencia_do_motor) {
		this.potencia_do_motor = potencia_do_motor;
	}
	public double getCusto_por_dia() {
		return custo_por_dia;
	}
	public void setCusto_por_dia(double custo_por_dia) {
		this.custo_por_dia = custo_por_dia;
	}
	
	
	
}
